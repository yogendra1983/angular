<?php
 
require_once 'application/config/database.php';
 
class DbHandler { 
    
   private $CI;
   
   function __construct() {
       $this->CI =& get_instance();
       $this->CI->load->database();
   }
   
   function getData(){
        $CI =& get_instance();
        $query  =   $CI->db->get('data');
        return $query->result();
    }



}
 
?>