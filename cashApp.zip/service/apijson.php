<?php 

class authenticateServices{    
    public  function __construct() {
	
    }
	
	/*// login user
	public function login(){
		
	
	}
	
	// login signup
	public function signup(){
		
	
	}*/
	
	
	 public function getlistservice($contentArr){
        
         try{             
             $dbhandler =new DbHandler(); 
             $corporateCode = $contentArr->params->corporateCode;           
            
             $listServiceDataAll = $dbhandler->getAllServiceLists();
              // print_r($listServiceDataAll); die;
			 header('Content-Type: application/json');
			 $response = array();               
			 $response['error']="false";
			 //$response['row'] = [];
			 $response['row'] = $listServiceDataAll;
			 $response['message']='List of All services';
			 echo json_encode($response);
						  
            }catch(Exception $e){
                $response = array();
                $response['error']="true";
                $response['message']=$e->getMessage();
                header('Content-Type: application/json');
                echo json_encode($response);
            }

     } // end function

     
  } // end class


        $authenticateObj =  new authenticateServices();
       // print_r($corporateObj );die;
        $content= file_get_contents('php://input'); 

        if (strpos($content,'generateXml') !== false) { 
			error_log($content);
            $content = str_replace(array("&","<",">","'"), "-", $content);          
        } 
        
        $contentArr = json_decode($content);
        $task = trim($contentArr->method);        

        switch($task){
         
        /*case 'login':
        $authenticateObj->login($contentArr);
        break;

        case 'signup':
        $authenticateObj->signup($contentArr);
        break;       
        case 'productdetails':
        $authenticateObj->getlistservice($contentArr);
        break;
        case 'pagedeatils':
        $authenticateObj->getPreciByservice($contentArr);
        break; */
		
		
		case 'category':
        $authenticateObj->availableServices($contentArr);
        break;
		       

    } 