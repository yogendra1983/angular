<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ajax extends CI_Controller {

	public function getContentStudenByClass()
	{
			$this->load->model(array('common_model'));			
			$classId = $_POST['classId'];
			
			if($classId != 'all')
				$this->db->where('classname',$classId);
			
			$this->db->select('studentid, studentName,phone');
			$this->db->order_by("studentName", "asc");
			$query = $this->db->get(STUDENT);
			$resultData = $query->result();
			$result = "";
			if ($query->num_rows() > 0)
			{
				foreach($resultData as $record)
				 {
			  		echo "<option value=".$record->studentid.">".ucwords(strtolower($record->studentName)).' ---------> '.$record->phone."</option>";
				 }
			}
			else
			{
				echo "<option vale='nodata'>No Records Found.</option>";
			}
	 }
	 
	 
	 
	 public function checkMobileExists()
	{
			$this->load->model(array('common_model'));
			$userid = $_POST['userid'];		
			$mobileno = $_POST['mobileno'];		
			$this->db->select('contactid');
			$this->db->where('contmobile',$mobileno);
			$this->db->where("userid",$userid);
			$query = $this->db->get(CONTACT);
			//$query = $this->db->get();
		    $rowcount = $query->num_rows();		
			
			if($rowcount > 0)
				 echo "<span style='font-size:12px; color:#009900;'>phone number already exists.</span>";
	 }
	 
	public function getcustomerautofilldata()
	 {
		$this->load->model(array('common_model'));
		 
		 $customers = $this->common_model->fetchFilteredResult($_POST['string']);
		 
		 //echo "<pre>"; print_r($customers); echo $customers['0']->contmobile; die;
		 
		 foreach($customers as $customer) {
		 ?>	 
		 <a href="javascript: void('0');" class="user_div" onclick="fillme('<?php echo $customer->codeName; ?>');"><span class="name"><?php echo $customer->codeName; ?></span></a>
         <?php
		  } 
		 exit;
	 }
	 
	 
	 public function getOrganizationsdata()
	 {
		 $this->load->model(array('common_model'));
		 
		 $organizations = $this->common_model->fetchOrganizationsFilteredResult($_POST['string'],$_POST['adminid']);
		 
		// echo "<pre>"; print_r($organizations); echo $organizations['0']->companyname; die;
		 
		 foreach($organizations as $organization) {
		 ?>	 
		 <a href="javascript: void('0');" class="user_div"><span class="name"><?php echo $organization->companyname; ?></span></a>
         <?php
		  } 
		 exit;
	 }
	 
	 
 
}
