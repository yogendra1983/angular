<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH . '/libraries/REST_Controller.php';
header("Access-Control-Allow-Origin: *");

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 */

 class Api extends REST_Controller
    {
        		
		function __construct()
        {
           parent::__construct();
           $this->load->database();
           $this->load->model('cm_apimodel_app');			
        }

        public function index_post()
        {
            // do nothing
        }

        public function index_get()
        {
            // do nothing
        }
        public function index_delete()
        {
            // do nothing
        }
        public function index_put()
        {
            // do nothing
        }
		
		/*** start banner web service   
		
		function banner_get()
		{
		  $bannerData = $this->cm_apimodel_app->getbannerList();

			if ($bannerData == '0')
					{
						$this->response(array('error' => '1', 'msg' => 'no record available'), 200);
					}
					else
					{
					  $bannerData = (array) $bannerData;

						echo json_encode(array(

							'error'   => '0',

							'message' => 'Success',

							'baseUrl' => base_url().'/uploads/',							
							
							'data'    => $bannerData

							));
					}		 
        }
        
        http://localhost/cmapp/api/signup
		
*/



function categorylist_get(){

    $catData = $this->cm_apimodel_app->getCategoryData();

    if (count($catData) < '1')
            {
                $this->response(array('error' => 'true', 'msg' => 'no record available'), 200);
            }
            else
            {
              $catData = (array) $catData;

                echo json_encode(array(
                    'error'   => 'false',
                    'message' => 'Success',
                    'data'    => $catData
                    ));
					
					/*header('Content-Type: application/json');
					$response = array();               
					$response['error']="false";
					$response['row'] = [];
					$response['row'] = $catData;
					$response['message']='List of All category';
					echo json_encode($response);*/

            }
    }
	
	

    



function listproduct_post(){

    $categorid = $this->input->post('categoryId');
    $productData = $this->cm_apimodel_app->getProductData($categorid);

    if (count($productData) < '1')
            {
                $this->response(array('error' => '1', 'msg' => 'no record available'), 200);
            }
            else
            {
              $productData = (array) $productData;

                echo json_encode(array(

                    'error'   => '0',

                    'message' => 'Success',                  						
                    
                    'data'    => $productData

                    ));
            }
    }
		
        // check login and create unique code. 

	function signup_post()
    { 
    $data = file_get_contents('php://input');    
    $userData = json_decode($data);

   //print_r($userData); die('hello');

     $username = $userData->username; 
     $password = $userData->password;
     $userEmailId = $userData->username;      
     $address = $userData->address;
     $state = $userData->state;      
     $city = $userData->city;
     $zip = $userData->zip;      
     $checkmeout = $userData->checkmeout;


     if (($username == ''))
        {
            $this->response(array('error' => 'Required params username'), 200);
        }
        else if (($password == ''))
        {
            $this->response(array('error' => 'Required params password'), 200);
        }
        else if (($userEmailId == ''))
        {
            $this->response(array('error' => 'Required params userEmailId'), 200);
        }
        // else if (($mobile == ''))
        // {
        //     $this->response(array('error' => 'Required params mobile'), 200);
        // }            
         else
        { 
            $dataInsert = array('username' => $username,
                                 'userPassword' => md5($password),
                                 'userEmailId' => $userEmailId,
                                 'emailId' => $userEmailId,
                                 'address' => $address, 
                                 'state' => $state,
                                 'city' => $city,
                                 'zip' => $zip,
                                 'checkmeout' => $checkmeout,                     
                                );

             // echo "<pre>"; print_r($dataInsert); die;                                
            
            // add insert user details.
            $this->db->insert('tblusers', $dataInsert); 
            $insertId = $this->db->insert_id();
          /*  echo $sql = "insert into tblusers (username, userPassword, userEmailId,emailId, address,state,city, zip ,checkmeout ) values 
            ('".$username."', '".md5($password)."', '".$userEmailId."', '".$userEmailId."','".$address."', '".state."', '".$city."', '".$zip."','".$checkmeout."')"; die;
            $this->db->query($sql);
            $insertId = $this->db->insert_id();

            */

            if($insertId>1){
                $this->response(array('error' => 'false', 'msg' => 'Registration has been successfully.'), 200);
            }else{
                $this->response(array('error' => 'true', 'msg' => 'Some Internal server error'), 200);                    
            }       

        } 
       
    }
		
		// send total Earn Point and Redeem Point Remaining Points.
        // post format {"username":"php.yogendra@gmail.com","password":123456}


		function login_post()
        {
                   
          $data = file_get_contents('php://input'); 
          $userData = json_decode($data); 
          //print_r($userData->username);

          $username = $userData->username;      
          $password = $userData->password;  


            if (($username == ''))
            {
                $this->response(array('error' => 'Required params username'), 200);
            }
			else if (($password == ''))
            {
                $this->response(array('error' => 'Required params password'), 200);
            }			
			
			else
            { 
                $userEmailId = $username;
                $userPassword = md5($password);
				
			if(!empty($userEmailId))
				{
					// check login 								
					$check = $this->cm_apimodel_app->checkLogin($userEmailId,$userPassword);
					if($check == 1)
					{
						
						echo json_encode(array(

							'error'   => 'false',

							'message' => 'Success'

							));							
						
					 }else
							{
									$this->response(array('error' => 'true', 'msg' => 'user name or password inVailid'), 200);
							}
				}					
				
            }           
        }
		

/**************End offer code ****************/
        
/***************** user information ***************/


function adduserinfo_post()
    { 
    $data = file_get_contents('php://input');    
    $userData = json_decode($data);

   ///print_r($userData); die('hello');

     $username = $userData->username;      
     $mobile = $userData->mobile;      
     $email_id = $userData->email_id;
     $occupation = $userData->occupation;  
    


     if (($username == ''))
        {
            $this->response(array('error' => 'Required params username'), 200);
        }
        else if (($mobile == ''))
        {
            $this->response(array('error' => 'Required params mobile'), 200);
        }
        else if (($email_id == ''))
        {
            $this->response(array('error' => 'Required params email id'), 200);
        }
        else if (($occupation == ''))
        {
            $this->response(array('error' => 'Required params occupation'), 200);
        }            
         else
        { 
            $dataInsert = array('username' => $username,                                 
                                'mobile' => $mobile,
                                'email_id' => $email_id, 
                                'occupation' => $occupation                                                   
                                );
                               // print_r($dataInsert); die('hello');                    
           
            $this->db->insert('tbluserInformation', $dataInsert); 
            $insertId = $this->db->insert_id();

       // print_r($dataInsert); die('hello');  
         
            if($insertId>1){
                $this->response(array('error' => 'false', 'msg' => 'User information has been added successfully.'), 200);
            }else{
                $this->response(array('error' => 'true', 'msg' => 'Some Internal server error'), 200);                    
            }       

        } 
       
    }

    function updateuserinfo_post()
    { 
    $data = file_get_contents('php://input');    
    $userData = json_decode($data);
   //print_r($userData); die('hello');
     $username = $userData->username;      
     $mobile = $userData->mobile;      
     $email_id = $userData->email_id;
     $occupation = $userData->occupation;
     $userid =   $userData->userid;    

   

     if (($userid == ''))
        {
            $this->response(array('error' => 'Required params updated record id'), 200);
        }else
        { 
            $dataUpdate = array('username' => $username,
                                 'mobile' => $mobile,
                                 'email_id' => $email_id, 
                                 'occupation' => $occupation                                                   
                                );                  
           
           // $this->db->insert('tbluserInformation', $dataInsert); 
           $insertId = $this->cm_apimodel_app->updateUser($userid,$dataUpdate);
           //print_r($dataUpdate); die('hello'); 

            if($insertId>0){
                $this->response(array('error' => 'false', 'msg' => 'Record has been updated successfully.'), 200);
            }else{
                $this->response(array('error' => 'true', 'msg' => 'Some Internal server error'), 200);                    
            }       

        } 
       
    }



    function userInfo_get(){

        $userData = $this->cm_apimodel_app->getUserInfoData();
    
        if (count($userData) < '1')
                {
                    $this->response(array('error' => 'true', 'msg' => 'no record available'), 200);
                }
                else
                {
                  $userData = (array) $userData;    
                    echo json_encode(array(
                        'error'   => 'false',
                        'message' => 'Success',
                        'data'    => $userData
                        ));
                }
        }









	
    }
