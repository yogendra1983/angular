<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MY_Controller extends CI_Controller {


 	public $userid= null;
	public $username= null;
		
    function __construct()
    {
        parent::__construct();
		
		 if (! $this->session->userdata('logged_in'))
			{
				redirect('login'); 
			}
			$this->userid =  $this->session->userdata['logged_in']['userId'];
			$this->username =  $this->session->userdata['logged_in']['username'];
    }
	
}

?>

