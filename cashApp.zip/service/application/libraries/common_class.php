<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Common_class {

    public function getFileExt($fileName){
		$ext = '';
		$ext = end(explode('.', $fileName));
		return $ext;
	}
	
	public function get_valid_name($string) {
		$valid_name = null;
		$replace_char = null;
	 
		if($string)
		{
	 
			$sps_chr_arr=array("--",",","\\","/","&quot;",".","'","!","@","#","$","%","^","&","*","(",")","+","=","-","[","]","{","}","<",">","?",";",",","|",":","`","~"," ");
			$m=1;
	  
			for($x=0;$x<strlen($string);$x++)
			{
				if(!in_array($string[$x],$sps_chr_arr) && $string[$x]!="\"")
				{
						$m='';
					if($replace_char)
					{
						$valid_name.=$replace_char;
						$replace_char='';
					}
						$valid_name.=$string[$x];
				
				}
				else if($m=='' && $string[$x]==" ")
				{
					$m=5;
					$replace_char="-";
				}
				}
		}

		return strtolower($valid_name);
 
	}
	
	public function test(){ echo 'testing goes here.';}
	
} /* End of file Someclass.php */