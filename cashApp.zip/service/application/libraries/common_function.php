<?php 

function pr($var){
	echo '<pre>';
	print_r($var);
	echo '</pre>';
}

function di(){
	die('<br>Testing goes here.<br>');

}