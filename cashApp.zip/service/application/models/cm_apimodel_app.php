<?php
    if (!defined('BASEPATH')) exit('No direct script access allowed');

    class Cm_apimodel_app extends CI_Model
    {

		
        /**
         * initializes the class inheriting the methods of the class My_Model 
         */
        public function __construct()
        {
            parent::__construct();
            $this->load->database();			
        }		
			
		public function checkLogin($userEmailId,$userPassword) 
		{ 
			$this ->db->select(' * ');
			$this ->db->from('tblusers');
            $this->db->where('userEmailId', $userEmailId);	
            $this->db->where('userPassword', $userPassword);			
			$query = $this->db-> get();
			if($query->num_rows() == 1) 
		    return 1;
			else
			return 0;
        } 
        
        public function getUserData(){
            $this->db->select(' userId,userEmailId,userPassword,status ');
            $this->db->from('tblusers');						
            $query = $this->db->get();            
            return $userData = $query->result();           
        }


        public function getCategoryData(){
            $this->db->select('id,category');
            $this->db->from('category');
            $this->db->where('status', '1');                          
            $query = $this->db->get();            
            return $userData = $query->result();           
        }


        public function getProductData($categoryId)
        {
            $this->db->select('pid,name,shortdes');
            $this->db->from('product');
            $this->db->where('cid', $categoryId);  
            $this->db->where('status', '1'); 
            $query = $this->db->get();            
            return $userData = $query->result();
        }

        public function updateUser($userid,$dataUpdate)
        {          
           $this->db->where('id', $userid);          
           $this->db->update('tbluserInformation', $dataUpdate);
           return 1;
        }

        

        public function getUserInfoData(){
            $this->db->select(' * ');
            $this->db->from('tbluserInformation');
            //$this->db->where('status', '1');                          
            $query = $this->db->get();            
            return $userData = $query->result();           
        }

     
    }
    