<?php
Class Common_model extends CI_Model
{
	function __construct(){
	   parent::__construct();
	} 


	public function get_result_where($table='', $where='') 
	{          
		$query = $this->db->query("SELECT * FROM $table $where");
		return $query->result();
	}

	public function get_single_field($field =array(), $table= '', $where='') 
	{          
		$query = $this->db->query("SELECT $field FROM $table $where");
		return $query->result();
	}

	public function update_data($table='',$data=array(),$where=''){
		$this->db->update($table, $data, $where);
		
	}

	public function insert_record($table='',$data=array()){
		$this->db->insert($table, $data);
		
		return $this->db->insert_id();
	}
	public function delete_record($table='',$where=''){
		$this->db->delete($table, $where); 
		
	}
	
	
	/*
	function displayChars($Chars,$len)
	{
		if(strlen($Chars)>$len){
		$Chars=substr($Chars,0,$len).'..';
		}
		 //$Chars=strip_tags(html_entity_decode($Chars));
         return $Chars;
    }
		 
	
	public function dateFormatPhp($date)
	{
		 $timestamp = strtotime($date);
		 $newDateFormat = date("d-m-Y H:i:s", $timestamp);
		 return $newDateFormat; 
	}
	
	
	 public function fetchFilteredResult($searchString = NULL) 
	{
		$query = $this->db->query("SELECT codeName FROM tblpincode WHERE status = '1' and codeName LIKE '".$searchString."%' limit 0, 15");
		return $query->result();
		//echo "<pre>"; print_r($query->result()); die;
	}
	*/
	
	
	public function getcategoryNameById($categoryId)
	{
		if($categoryId == '0')
		{
			$categoryname = "Parent";
			return $categoryname;
		}
		else{		
		 $this->db->select('id,category,parentId');
		  $this->db->where('id', $categoryId);
		 $query = $this->db->get(CATEGORY);				
		 $rowdata =  $query->row();		 
    	 return ucwords(strtolower($rowdata->category)); 
		 }
	}
	
	public function get_subcategory($sid = NULL) 
	{          
		  $this->db->select('id,category');
		  $this->db->where('parentId', $sid);
		  $this->db->where('status', '1');
		  $this->db->order_by("category", "asc");
		  $query = $this->db->get(CATEGORY);				
		  return $query->result();
	}
	
	public function get_ssubcategory($ssid = NULL) 
	{          
		  $this->db->select('id,category');
		  $this->db->where('parentId', $ssid);
		  $this->db->where('status', '1');
		  $this->db->order_by("category", "asc");
		  $query = $this->db->get(CATEGORY);				
		  return $query->result();
	}
	
	public function getProductName($productId)
	{
	      $this->db->select('name');
		  $this->db->where('pid', $productId);
		  $query = $this->db->get(PRODUCT);				
		  $rowdata =  $query->row();		 
    	 return ucwords(strtolower($rowdata->name)); 
	}
	
	
	public function getBrandlist() 
	{          
		  $this->db->select('brandId,brandName');
		  $this->db->where('status', '1');
		  $this->db->order_by("brandName", "asc");
		  $query = $this->db->get(BRAND);				
		  return $query->result();
	}
	
	public function categoryListMenu()
	{
		$this->db->select("id,category");
		$this->db->order_by("id", "ASC");
		$this->db->where("status",'1');
		$query = $this->db->get(CATEGORY);	
		//echo "<pre>"; print_r($query->result()); die;
		return $query->result();
	}
	
	public function frontCategoryNameById($categoryId)
	{
		 $this->db->select('category');
		  $this->db->where('id', $categoryId);
		 $query = $this->db->get(CATEGORY);				
		 $rowdata =  $query->row();		 
    	 return ucwords(strtolower($rowdata->category)); 
	}
	
	public function productImageById($pid)
	{
		  $this->db->select('producttitleimage,productimagename');
		  $this->db->where('pid', $pid);
		  $this->db->group_by("pid");
		 $query = $this->db->get(PRODUCTIMAGE);				
		 return $query->result();
	}
	
	public function checkSsessionItems(){
			$item = $this->cart->total_items();
			return $item;				
	}
	
	public function removeAllItems()
	{
		$rowid = $this->uri->segment(2);
		if ($rowid==="all")
		{                      
			$this->cart->destroy();
			redirect('index');
		}	
				
	}
	
	
	
}

?>