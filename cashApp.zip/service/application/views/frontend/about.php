<!-- <div style="background-color:#FF0000;z-index:11111; position:relative; float:right; "><h1>Yogendra Kumar<h1></div>-->  
<div class="gap"></div>
	
 <div class="profile-box">
 
       <div class="profile-pink text-right">
         <h1 class="white cap">Incorporated in 2009</h1>
         <h5 class="white">Art View is a fully compliance (Sedex Members Ethical Trade Audit/Business Social Compliance Initiative)<br> export house recognized by govt. of India. This company was promoted in 2014 by Mr. XYZ and Mr. ABC<br> who have vast experience in this industry and was associated with this industry from 1975 onwards.<br> During last 2 decades the only point of our success is good quality and timely deliveries.</h5>
       </div>
       <div class="gap"></div>
       <div class="gap"></div>
       <div class="gap"></div>
       
       <div class="profile-grn">
         <h3 class="white cap text-center">Partnership Firm</h3>
         <h5 class="white">The company is being managed by the directors that includes Mr. XYZ and Mr. ABC who have more than 3 decades experience in the different capacities and around 2 decades experience to manage...</h5>
       </div>
       
       <div class="profile-ylw">
         <h3 class="white cap text-center">3000 sq feet Shopping Mall
in heart of Dadar</h3>
         <h5 class="white">Sedex Members Ethical Trade Audit (http://www.sedexglobal.com), BSCI - Business Social Compliance Initiative (http://www.bsci-intl.org) ...  </h5>
       </div>
    </div>
	
	
	
	
	
	
	
	
	
	
	
	</div>

</section>


<!-- Vendor --> 
<script src="<?php echo base_url('assets/frontend/js/jquery.browser.mobile.js');?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/bootstrap.js'); ?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/nanoscroller.js'); ?>"></script> 
<!-- Theme Base, Components and Settings --> 
<script src="<?php echo base_url('assets/frontend/js/theme.js'); ?>"></script> 
</body>
</html>