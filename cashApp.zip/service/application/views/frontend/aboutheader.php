<body>
<div id="background"><img src="<?php echo base_url('assets/frontend/img/profile-banner.jpg'); ?>" alt=""></div>
<section class="body"> 
  
  <!-- start: header -->
  <header class="header">
    <div class="logo-container"> <a href="index.html" class="logo"> <img src="<?php echo base_url('assets/frontend/img/logo.PNG'); ?>"  alt="" /> </a>
      <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened"> <i class="fa fa-bars" aria-label="Toggle sidebar"></i> </div>
    </div>
    
    
  </header>