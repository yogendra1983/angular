<div class="products-box">
       <div class="col-sm-6">
        <h2 class="white cap trajan"><?php echo $this->common_model->frontCategoryNameById($cid); ?></h2>
        <img src="<?php echo base_url('assets/frontend/img/title-line.PNG'); ?>">
       </div>
       <!--<div class="col-sm-6">
          <img src="img/display2.PNG" class="right-icon">
          <img src="img/display1.PNG" class="right-icon">
          <p class="right-icon white">Display: </p>
          <div class="right-select">
          <select class="right-icon">
             <option>Default</option>
             <option>Default</option>
             <option>Default</option>
          </select>
          </div>
          <p class="right-icon white">Sort by:</p>
       <div class="clearfix"></div>
       </div>--> 
       <div class="clearfix"></div>
       <div class="gap"></div>
       <div class="gap"></div>
	   
	<?php foreach ($allproduct as $k => $record) { 
	$product = $this->common_model->productImageById($record->pid);
	 
	?>
       <div class="col-sm-4">
          <div class="product-box">
             <a href="<?php echo base_url('productdetails').'/'.$record->pid.URL_EXT; ?>"><img src="<?php echo base_url(''); ?>uploads/product/<?php echo $product['0']->productimagename ;?>" title="<?php echo $product['0']->producttitleimage ;?>"></a>
			 
			 <?php if($record->newlaunch=='1') { ?>
             <a href="<?php echo base_url('productdetails').'/'.$record->pid.URL_EXT; ?>" class="new">NEW</a>
			 <?php } ?>
             <a href="<?php echo base_url('productdetails').'/'.$record->pid.URL_EXT; ?>" class="cart"><h4 style="margin-bottom:2px; margin-top:2px;"><?php echo $record->name; ?></h4></a>
          </div>
          <div class="clearfix"></div>
          <div class="gap"></div>
		  <h4 class="trajan no-marg white text-center">Price <?php echo number_format($record->price, 2, '.', ''); ?></h4>
          <!--<a href="<?php echo base_url('productdetails').'/'.$record->pid.URL_EXT; ?>"><h4 class="trajan no-marg white text-center"><?php echo $record->name; ?></h4></a>
          <p class="white text-center">Price <?php echo number_format($record->price, 2, '.', ''); ?></p>--> 
		  
      </div>
    <?php } ?>   
       
       
       <div class="clearfix"></div>
       <div class="gap"></div>
    
    </div>
	</div>


</section>


<!-- Vendor --> 
<script src="<?php echo base_url('assets/frontend/js/jquery.browser.mobile.js');?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/bootstrap.js'); ?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/nanoscroller.js'); ?>"></script> 
<!-- Theme Base, Components and Settings --> 
<script src="<?php echo base_url('assets/frontend/js/theme.js'); ?>"></script> 
</body>
</html>