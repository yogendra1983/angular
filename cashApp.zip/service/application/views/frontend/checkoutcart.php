 <script type="text/javascript" src="<?php echo base_url('assets/script/jquery.validate.min.js'); ?>"></script>
 <script src="<?php echo base_url('assets/script/formvalidation.js');?>" type="text/javascript"></script> 

<div class="products-box" style="top:1%;">
       <div class="col-sm-6">
        <h2 class="white cap trajan">order summary <?php echo $this->cart->total_items(); ?> Items</h2>
        <img src="<?php echo base_url('assets/frontend/img/title-line.PNG'); ?>">
       </div>
	   
	   <div class="row">
          
		  <div class="col-lg-12" style="padding-top:10px;">
				   
                      <div class="panel panel-default">
                       
                        <!-- /.panel-heading -->
                        <div class="panel-body">
						
						<?php 
							 $cart_check = $this->cart->contents();
								if(!empty($cart_check)) {
						 ?>
			
                            <div class="table-responsive">
                                <table width="1311" class="table table-hover">
								    <thead>
                                        <tr>
										<th width="100" class="shopping-heading">No.</th>
                                        <th width="345" class="shopping-heading">Image </th>
                                        <th width="348" class="shopping-heading">Product</th>
                                        <th width="212" class="shopping-heading">Price</th>
										<th width="138" class="shopping-heading">Quantity</th>										
										<th width="140" class="shopping-heading">Total Price</th>
										
                                    </tr>
                                    </thead>
                                    <tbody>
							<?php
								 $cartData = $this->cart->contents(); 
								/// echo "<pre>"; print_r($cartData);
									$k=1;
								  foreach ($cartData as  $record)
								  { 
								  $proImage = $this->common_model->productImageById($record['id']);
							?>	
									<tr>
										<td><?php echo $k++; ?>.</td>
										<td><img src="<?php echo base_url(''); ?>uploads/product/<?php echo $proImage['0']->productimagename ;?>" title="<?php echo $proImage['0']->producttitleimage ;?>" width="72" height="42"></td>	
										<td><?php echo $record['name']; ?></td>	
										<td><?php echo CURRENCY.$record['price']; ?></td>	
										<td>
										<?php echo $record['qty']; ?>
										</td>	
										<td><?php
										   $grand_total = $grand_total + $record['subtotal']; 
										   echo CURRENCY.$record['subtotal']; ?></td>	
										
											</tr>
									<?php } ?>
									
									
						<form name="frmcheckout" id="frmcheckout" action="<?php echo base_url("checkout").URL_EXT; ?>" method="post">
									
						<tr>
							<td colspan="6" style="background-color:#FFFFFF;">
								<table width="100%" class="table table-hover">
								
								<tr>
									<td colspan="4" style="background-color:#6eb5b1;"><h2 class="white cap trajan" style="margin-bottom: 0;">Shipping Address </h2> </td>
								</tr>
								
								<tr>
									<td width="17%"> Full Name : <span class=required>*</span> </td>
							      <td width="35%"><input type="text" name="username" id="username" value="" style="width:250px;" /></td>
									 
									 <td width="15%">Address Line 1 : <span class=required>*</span> </td>
								  <td width="33%"><input type="text" name="address1" id="address1" value="" style="width:250px;" /></td>
								</tr>
								
								<tr>
									<td style="border-top: 1px solid #FFFFFF;">Address Line 2 : <span class=required>*</span></td>
									<td style="border-top: 1px solid #FFFFFF;"><input type="text" name="address2" id="address2" value=""  style="width:250px;" /></td>
									<td style="border-top: 1px solid #FFFFFF;">State : <span class=required>*</span> </td>
									<td style="border-top: 1px solid #FFFFFF;"><input type="text" name="state" id="state" value=""  style="width:250px;"/></td>
								</tr>
								
								<tr>
									<td style="border-top: 1px solid #FFFFFF;">City : <span class=required>*</span> </td>
									<td style="border-top: 1px solid #FFFFFF;"><input type="text" name="city" id="city" value="" style="width:250px;"/></td>
									<td style="border-top: 1px solid #FFFFFF;">Pin code : <span class=required>*</span> </td>
									<td style="border-top: 1px solid #FFFFFF;"><input type="text" name="pincode" id="pincode" value=""style="width:250px;" /></td>
								</tr>
								
								<tr>
									<td style="border-top: 1px solid #FFFFFF;">Phone : <span class=required>*</span> </td>
									<td style="border-top: 1px solid #FFFFFF;"><input type="text" name="phone" id="phone" value="" style="width:250px;" />
									 <div class="error"><?php echo form_error('phone'); ?></div></td>
									<td style="border-top: 1px solid #FFFFFF;">Email Id : <span class=required>*</span> </td>
									<td style="border-top: 1px solid #FFFFFF;"><input type="text" name="emailid" id="emailid" value="" style="width:250px;" />
									 <div class="error"><?php echo form_error('emailid'); ?></div></td>
								</tr>
								<input type="hidden" name="totalpayment" id="totalpayment" value="<?php echo $grand_total; ?>" />
								
								
								
								<!--<tr>
									<td>Cash On Delivery :  </td>
									<td><input type="radio" name="paymenttype" id="paymenttype" value="1" checked="checked" /></td>
									<td colspan="2">&nbsp;</td>
								</tr>-->
								
								<tr>
									
							<td colspan="4"> <strong style="font-size:16px;">Payment Type :</strong> <input type="radio" name="paymenttype" id="paymenttype" value="cashon" checked="checked" />&nbsp; Cash On Delivery&nbsp;&nbsp;<input type="radio" name="paymenttype" id="paymenttype" value="onlinepayment"  />&nbsp;&nbsp;Payment Method </td>
									<!--<td colspan="2"> Payment Method :  <input type="radio" name="paymenttype" id="paymenttype" value="1"  /></td>-->
									
								</tr>
								
								<!--<tr>
									<td style="border-top: 1px solid #FFFFFF;">Payment Method :  </td>
									<td style="border-top: 1px solid #FFFFFF;"><input type="radio" name="paymenttype" id="paymenttype" value="2" /></td>
									<td colspan="2" style="border-top: 1px solid #FFFFFF;">&nbsp;</td>
								</tr>-->
								
								<tr id="showpayment1" style="display:none;">
									<td>Card No</td>
									
									<td colspan="3">&nbsp;</td>
								</tr>
								
								
								
								
								
								
							</table>
							
							</td>
							
							
						</tr>
					<tr> 
							<td colspan="2"><button style="width:270px; font-size:14px; font-weight:bold;" class="md-shoppinbutton">Proceed To Pay Rs <?php  echo CURRENCY.number_format($grand_total, 2); ?></button></td>
							<td colspan="2">&nbsp;</td>
							<td colspan="2"> <!--<strong>Amount Payable :</strong> <?php // echo CURRENCY.number_format($grand_total, 2); ?>--></td>
					</tr>
				</form>					
                                    </tbody>
                              </table>
							  
							  
							
                            </div>
							<?php
							  }
							?>
                        </div>
                       </div>
                    </div>
		  
	   </div>	  
	   
	   
	   
	   
	   
    </div>
	</div>

<!-- Vendor --> 
<script src="<?php echo base_url('assets/frontend/js/jquery.browser.mobile.js');?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/bootstrap.js'); ?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/nanoscroller.js'); ?>"></script> 
<!-- Theme Base, Components and Settings --> 
<script src="<?php echo base_url('assets/frontend/js/theme.js'); ?>"></script> 
</body>
</html>