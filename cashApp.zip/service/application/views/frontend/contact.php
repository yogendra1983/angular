<div class="contact-box">
       <div class="contact-box1">
         <h3 class="white cap text-center">Enquire Now to Connect</h3>
         <div class="small-gap"></div>
    <form class="form1" method="post" name="form1" action="" onSubmit="return validateform();" >
      <input class="enquire-input" type="text" name="name" placeholder="Name"/>
      <div class="small-gap"></div>
      <input class="enquire-input" type="text" name="email" placeholder="Emails"/>
      <div class="small-gap"></div>
      <input class="enquire-input" type="text" name="phone" placeholder="Phone"/>
      <div class="small-gap"></div>
      <textarea class="enquire-input message" name="query"  placeholder="Message"></textarea>
      <div class="small-gap"></div>
      <div>
        <input type="image" name="submit" src="<?php echo base_url('assets/frontend/img/submit.png'); ?>" class="img-responsive" style="margin-bottom:2px;" />
      </div>
      <div class="clearfix"></div>
    </form>
    <script language="JavaScript" type="text/javascript">var frm =new Validator("form1");
			frm.addValidation("name","req","Enter Your Name");
			frm.addValidation("phone","req","Enter Your Phone Number");
			frm.addValidation("email","req","Enter Your Email");
			frm.addValidation("query","req","Enter Your Message");
			
	</script>
       </div>
       
       <div class="contact-box2">
         <h3 class="white cap">Contact Us</h3>
         <div class="gap"></div>
         <p class="white">G-172, 1st FLOOR, <br>
Sector 63<br>
Noida- 201301<br>
PH: 0120 4372777<br>
MOB: +91 921 155 6666<br>
EMAIL: INFO@Sandhyasoni.COM<br>

ANY QUESTIONS? CLICK HERE</p>
       </div>
    </div>
	
	</div>

</section>


<!-- Vendor --> 
<script src="<?php echo base_url('assets/frontend/js/jquery.browser.mobile.js');?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/bootstrap.js'); ?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/nanoscroller.js'); ?>"></script> 
<!-- Theme Base, Components and Settings --> 
<script src="<?php echo base_url('assets/frontend/js/theme.js'); ?>"></script> 
</body>
</html>