
<!-- Vendor --> 
<script src="<?php echo base_url('assets/frontend/js/jquery.browser.mobile.js');?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/bootstrap.js'); ?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/nanoscroller.js'); ?>"></script> 


<!-- Theme Base, Components and Settings --> 
<script src="<?php echo base_url('assets/frontend/js/theme.js'); ?>"></script> 


</body>

<!-- Mirrored from preview.oklerthemes.com/porto-admin/1.4.1/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 23 May 2015 06:56:10 GMT -->
</html>