<!doctype html>
<html class="fixed">
<head>

<!-- Basic -->
<meta charset="UTF-8">
<title>~ Art View ~</title>

<!-- Mobile Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

<!-- Web Fonts  -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

<link href='http://fonts.googleapis.com/css?family=Patua+One' rel='stylesheet' type='text/css'>

<!-- Vendor CSS -->
<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/bootstrap.css'); ?>" />

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/frontend/css/jquery-responsiveGallery.css') ; ?>">


<link rel="stylesheet" href="<?php echo base_url('assets/frontend/assets/vendor/font-awesome/css/font-awesome.css'); ?>" />

<!-- Theme CSS -->
<link rel="stylesheet" href="<?php echo base_url('assets/frontend/assets/stylesheets/theme.css'); ?>" />
<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/style.css'); ?>" />


<!-- Head Libs -->
<script src="<?php echo base_url('assets/frontend/js/modernizr.js'); ?>"></script>
<script src="<?php echo base_url('assets/frontend/js/jquery.min.js'); ?>" type="text/javascript"></script>

<!-- Add mousewheel plugin (this is optional) -->
	<script type="text/javascript" src="<?php echo base_url('assets/frontend/fancybox/js/jquery.mousewheel-3.0.6.pack.js'); ?>"></script>

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="<?php echo base_url('assets/frontend/fancybox/js/jquery.fancybox.js'); ?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/frontend/fancybox/css/jquery.fancybox.css'); ?>" media="screen" />


	<script type="text/javascript">
		$(document).ready(function() {
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

			/*
			 *  Different effects
			 */

		});
	</script>
    

<script type="text/javascript" src="<?php echo base_url('assets/frontend/js/modernizr.custom.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url('assets/frontend/js/jquery.responsiveGallery.js'); ?>"></script>
	<script type="text/javascript">
		$(function () {
$('.responsiveGallery-wrapper').responsiveGallery({
	animatDuration: 400,
	$btn_prev: $('.responsiveGallery-btn_prev'),
	$btn_next: $('.responsiveGallery-btn_next')
});
		});
		
	</script>
</head>

<script>
function storeproduct(proid)
{
document.getElementById('cpid').value=proid;
var q=document.getElementById('qty1').value;
document.getElementById('productqty').value=q;
}
function val(a)
{
if(isInteger(a)==false)
		{
			alert('Enter Price Amount Must Be Number!');
			document.getElementById('qty1').value="";
			document.getElementById('qty1').focus();
			return false;
		}

document.getElementById('qty1').value=a;
}
function isInteger(s)
{   var i;
    for (i = 0; i < s.length; i++)
    {   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

</script>
