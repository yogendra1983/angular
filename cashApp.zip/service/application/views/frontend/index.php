<!doctype html>
<html class="fixed">
<head>

<!-- Basic -->
<meta charset="UTF-8">
<title>~ Art View ~</title>

<!-- Mobile Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

<!-- Web Fonts  -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

<link href='http://fonts.googleapis.com/css?family=Patua+One' rel='stylesheet' type='text/css'>

<!-- Vendor CSS -->
<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/bootstrap.css'); ?>" /> 

<link href="<?php echo base_url('assets/frontend/css/bannerscollection_zoominout.css');?>" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/style.css'); ?>" />


<!-- Head Libs -->
<script src="<?php echo base_url('assets/frontend/js/jquery.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/frontend/js/jquery-ui.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/frontend/js/jquery.ui.touch-punch.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/frontend/js/bannerscollection_zoominout.js'); ?>" type="text/javascript"></script>
<!-- must have -->

<script>
		jQuery(function() {
			jQuery('#bannerscollection_zoominout_majestic').bannerscollection_zoominout({
				skin: 'majestic',
				responsive:true,
				width: 1920,
				height: 1200,
				width100Proc:true,
				height100Proc:true,
				fadeSlides:1,
				showNavArrows:true,
				showBottomNav:true,
				autoHideBottomNav:true,
				thumbsOnMarginTop:18,
				thumbsWrapperMarginTop: -135,
				pauseOnMouseOver:false
			});		
			
		});
		
	</script>
    
</head>
<body>
<section class="body"> 
    
    <div id="bannerscollection_zoominout_majestic">
      <div class="myloader"></div>
       <!-- CONTENT -->
        <ul class="bannerscollection_zoominout_list">
          <li data-initialZoom="1" data-finalZoom="0.80" data-text-id="#bannerscollection_zoominout_photoText1" data-horizontalPosition="center" data-verticalPosition="center" data-bottom-thumb="<?php echo base_url('assets/frontend/img/banner-1.jpg'); ?>" ><img src="<?php echo base_url('assets/frontend/img/banner-1.jpg'); ?>" alt="" width="2200" height="1170" /></li>
          <li data-initialZoom="1" data-finalZoom="0.80" data-text-id="#bannerscollection_zoominout_photoText1" data-horizontalPosition="center" data-verticalPosition="center" data-bottom-thumb="<?php echo base_url('assets/frontend/img/banner-1.jpg'); ?>" ><img src="<?php echo base_url('assets/frontend/img/banner-1.jpg'); ?>" alt="" width="2200" height="1170" /></li>
          <li data-initialZoom="1" data-finalZoom="0.80" data-text-id="#bannerscollection_zoominout_photoText1" data-horizontalPosition="center" data-verticalPosition="center" data-bottom-thumb="<?php echo base_url('assets/frontend/img/banner-1.jpg'); ?>" ><img src="<?php echo base_url('assets/frontend/img/banner-1.jpg'); ?>" alt="" width="2200" height="1170" /></li>
        </ul>
        
        <!-- TEXTS -->
               
               <div id="bannerscollection_zoominout_photoText1" class="bannerscollection_zoominout_texts">
                    <div class="bannerscollection_zoominout_text_line textElement71_majestic" 
                       data-initial-left="0" 
                       data-initial-top="400" 
                       data-final-left="500" 
                       data-final-top="400" 
                       data-duration="0.4" 
                       data-fade-start="0" 
                       data-delay="0.3"
                       data-exit-left="-300"
                       data-exit-duration="0.5"
                       data-exit-delay="0.3"
                       data-exit-fade="0">
                      <div class="banner-txt1">Fashioned by Art View</div>
                    </div>
                    
                    
                    <div class="bannerscollection_zoominout_text_line textElement73_majestic" 
                    data-initial-left="1500" 
                    data-initial-top="460" 
                    data-final-left="500" 
                    data-final-top="460" 
                    data-duration="1" 
                    data-fade-start="0" 
                    data-delay="0.6">
                    <div class="banner-txt2 cap"><a href="<?php echo base_url("index").URL_EXT; ?>">Enter Website</a></div>
                    </div>          
               </div> <!--End First Slide Texts-->
               

       <!-- TEXTS --> 
       <!--EndTexts--> 
      </div>

</section>



</body>

<!-- Mirrored from preview.oklerthemes.com/porto-admin/1.4.1/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 23 May 2015 06:56:10 GMT -->
</html>