  <div class="inner-wrapper"> 
    <!-- start: sidebar -->
    <aside id="sidebar-left" class="sidebar-left">
      <div class="nano">
        <div class="main-logo"><a href="<?php echo base_url("index").URL_EXT; ?>"><img src="<?php echo base_url('assets/frontend/img/logo.PNG'); ?>" class="img-responsive center-block"></a>
		
		<div style="padding-top:10px;"><a href="<?php echo base_url("cart").URL_EXT; ?>" class="shopping-box">Shopping Cart</a></div>
		<div><span class="itemhead">Item(s) : <?php $totalitem = $this->cart->total_items(); if($totalitem == 0) echo $totalitem; else echo $totalitem;  ?></span>|<span class="itemhead"><?php  $totalamount = $this->cart->total(); if($totalamount == 0) echo CURRENCY.number_format($totalamount, 2); else echo CURRENCY.number_format($totalamount, 2); ?></span></div>
		
		</div>
		
		
		
        <div class="nano-content">
          <nav id="menu" class="nav-main" role="navigation">
            <ul class="nav nav-main">
              <li> <a href="<?php echo base_url("about").URL_EXT; ?>"> <span>About Art View</span> </a> </li>
              <li class="nav-parent nav-active"> <a> <span>Product Line</span> </a>
                <ul class="nav nav-children">
				
				<?php
				$categorylist = $this->common_model->categoryListMenu();
				foreach ($categorylist as $k => $record)
				 {
				?>
                  <li> <a href="<?php echo base_url('categorylist').'/'.$record->id.URL_EXT; ?>"><span><img src="<?php echo base_url('assets/frontend/img/sub-arrow.png'); ?>" style="position:relative; top:-4px;"></span> <?php echo $record->category; ?> </a> </li>
				  
				  <?php } ?>
				  
                </ul>
              </li>
              <li> <a href="<?php echo base_url("contact").URL_EXT; ?>"> <span>Contact Us</span> </a> </li>
              
            </ul>
          </nav>
          <hr class="separator" />
        </div>
		
		
        
        <div class="socials">
            <h5 class="text-center white">Follow Us On</h5>
            <ul class="social-icons">
              <li><a href="#"><img src="<?php echo base_url('assets/frontend/img/social-1.png'); ?>"></a></li>
            </ul>
           <!-- <p class="text-center white small-p">Online Agency : <a href="http://eduviewers.com/" target="_blank">Education Viewers</a></p>-->
          </div>
          
      </div>
    </aside>
    <!-- end: sidebar -->