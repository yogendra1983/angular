 <div class="products-box">
       <div class="col-sm-8">
        <h2 class="white cap trajan"><?php echo $this->common_model->frontCategoryNameById($productDetails['0']->cid); ?> <span style="color:#000;"> >> <?php echo $productDetails['0']->name; ?></span></h2>
		<img src="<?php echo base_url('assets/frontend/img/title-line.PNG'); ?>">
       </div>
	    <form method="post" name="qtyform" action="<?php echo base_url("cart").URL_EXT; ?>">
			   <div class="col-sm-4">
				  <h4 class="right-icon white">Quantity : <input style="color:#333333; width:40px;" type="text" value="1" name="qty" id="qty" maxlength="3" />
				  </h4>
				  <h4 class="right-icon white">Price : <?php echo number_format($productDetails['0']->price, 2, '.', ''); ?></h4>
			   </div> 
			   <div class="col-sm-4">
				  <input type="submit"  value="ADD TO CART" class="right-icon white add-cart" onClick="return storeproduct('<?php echo $productDetails['0']->pid; ?>');" >
					  <input type="hidden" name="name" id="name"  value="<?php echo $productDetails['0']->name; ?>" />	
					  <input type="hidden" name="price" id="price" value="<?php echo $productDetails['0']->price; ?>" />
					  <input type="hidden" name="pid" value="<?php echo $productDetails['0']->pid; ?>" />
			   </div>
		</form>	
		
       <div class="clearfix"></div>
       <div class="gap"></div>
       <div class="gap"></div>
       
       <div class="col-sm-5">
          <div id="carousel-wrapper">
				<div id="carousel">
				
				     <?php foreach ($productImages as $k => $record) { ?>
				
							<span id="product-img<?php echo $k + 1; ?>"><img src="<?php echo base_url(''); ?>uploads/product/<?php echo $record->productimagename ;?>" title="<?php echo $record->producttitleimage ;?>"></span>
					
					
					<?php } ?>
				</div>
			</div>
			<div id="thumbs-wrapper">
				<div id="thumbs">
				 <?php foreach ($productImages as $k => $record) { ?>
					<a href="#product-img<?php echo $k + 1; ?>"><img src="<?php echo base_url(''); ?>uploads/product/<?php echo $record->productimagename ;?>" title="<?php echo $record->producttitleimage ;?>" width="125" height="85"></a>
					<?php } ?>
					
				</div>
				<a id="prev" href="#"></a>
				<a id="next" href="#"></a>
			</div>
       </div>
       
       <div class="col-sm-6 white">
          <h3 class="trajan"><?php echo $productDetails['0']->name; ?></h3>

<h5>AVAILABILITY: In Stock
PRODUCT CODE: <?php echo $productDetails['0']->code; ?></h5>


<p><span class="orange">SPECIFICATIONS</span><br>
<?php echo $productDetails['0']->shortdes; ?>
</p>

       <div class="gap"></div>
<!--<select style="color:#000;">
   <option>Magenta</option>
   <option>Magenta</option>
   <option>Magenta</option>
   <option>Magenta</option>
   <option>Magenta</option>
</select>
<input type="text" style="width:100px;">
-->       </div>
       
       <div class="clearfix"></div>
       <div class="gap"></div>
       
       <div class="col-sm-3 white">
        <h4 class="white cap trajan">MEASUREMENT</h4>
        <img src="<?php echo base_url('assets/frontend/img/title-line.PNG'); ?>" class="img-responsive">
        
        <p>
		<?php echo $productDetails['0']->measurement; ?>
		
		</p>
       </div>
       
       <div class="col-sm-4 white">
        <h4 class="white cap trajan">MATERIAL INFO</h4>
        <img src="<?php echo base_url('assets/frontend/img/title-line.PNG'); ?>" class="img-responsive">
        
        <p><?php echo $productDetails['0']->material; ?></p>
       </div>
       
       <div class="col-sm-5 white">
        <h4 class="white cap trajan">SHIPPING AND ADDITIONAL INFO</h4>
        <img src="<?php echo base_url('assets/frontend/img/title-line.PNG'); ?>" class="img-responsive">
        
        <p><?php echo $productDetails['0']->productdes; ?></p>
       </div>
       
    </div>
	
</section>

<!-- Vendor --> 
<script src="<?php echo base_url('assets/frontend/js/jquery.browser.mobile.js');?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/bootstrap.js'); ?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/nanoscroller.js'); ?>"></script> 
<!-- Theme Base, Components and Settings --> 
<script src="<?php echo base_url('assets/frontend/js/theme.js'); ?>"></script> 
</body>
</html>