<link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/product-style.css'); ?>" />
<script src="<?php echo base_url('assets/frontend/js/jquery.carouFredSel-6.0.4-packed.js'); ?>" type="text/javascript"></script>
		<script type="text/javascript">
			$(function() {
				
				$('#carousel span').append('<img src="<?php echo base_url('assets/frontend/img/gui/carousel_glare.png'); ?>" class="glare" />');
				$('#thumbs a').append('<img src="<?php echo base_url('assets/frontend/img/gui/carousel_glare_small.png'); ?>" class="glare" />');

				$('#carousel').carouFredSel({
					responsive: true,
					circular: false,
					auto: false,
					items: {
						visible: 1,
						width: 200,
						height: '56%'
					},
					scroll: {
						fx: 'directscroll'
					}
				});

				$('#thumbs').carouFredSel({
					responsive: true,
					circular: false,
					infinite: false,
					auto: false,
					prev: '#prev',
					next: '#next',
					items: {
						visible: {
							min: 2,
							max: 6
						},
						width: 150,
						height: '66%'
					}
				});

				$('#thumbs a').click(function() {
					$('#carousel').trigger('slideTo', '#' + this.href.split('#').pop() );
					$('#thumbs a').removeClass('selected');
					$(this).addClass('selected');
					return false;
				});

			});
		</script>

<body>
<div id="background"><img src="<?php echo base_url('assets/frontend/img/listing-banner.JPG'); ?>" alt=""></div>
<section class="body"> 
  
  <!-- start: header -->
  <header class="header">
    <div class="logo-container"> <a href="index.html" class="logo"> <img src="<?php echo base_url('assets/frontend/img/logo.PNG'); ?>"  alt="" /> </a>
      <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened"> <i class="fa fa-bars" aria-label="Toggle sidebar"></i> </div>
    </div>
  </header>



