 <script type="text/javascript">
            // To conform clear all data in cart.
            function clear_cart() {
                var result = confirm('Are you sure want to clear all bookings?');

                if (result) {
                    window.location = "<?php echo base_url('cartremove').'/all'; ?>"
                } else {
                    return false; // cancel button
                }
            }
        </script>

<div class="products-box" style="top:1%;">
       <div class="col-sm-6">
        <h2 class="white cap trajan">Shopping Cart</h2>
        <img src="<?php echo base_url('assets/frontend/img/title-line.PNG'); ?>">
       </div>
	   
	   <div class="row">
          
		  <div class="col-lg-12" style="padding-top:10px;">
				   
                      <div class="panel panel-default">
                       
                        <!-- /.panel-heading -->
                        <div class="panel-body">
						
						<?php 
							 $cart_check = $this->cart->contents();
								if(!empty($cart_check)) {
						 ?>
			
                            <div class="table-responsive">
                                <table width="1311" class="table table-hover">
								    <thead>
                                        <tr>
										<th width="48" class="shopping-heading">No.</td>
                                        <th width="308" class="shopping-heading">Image </th>
                                        <th width="312" class="shopping-heading">Product</th>
                                        <th width="112" class="shopping-heading">Price</th>
										<th width="123" class="shopping-heading">Quantity</td>										
										<th width="198" class="shopping-heading">Total Price</th>
										<th width="178" class="shopping-heading">Remove</th>
                                    </tr>
                                    </thead>
                                    <tbody>
									
									 <form method="post" action="<?php echo base_url("cartupdate").URL_EXT; ?>">
							<?php
								 $cartData = $this->cart->contents(); 
								/// echo "<pre>"; print_r($cartData);
									$k=1;
								  foreach ($cartData as  $record)
								  { 
								  $proImage = $this->common_model->productImageById($record['id']);
							?>	
									
									<input type="hidden" name="cart[<?php echo $record['id']; ?>][id]"  value="<?php echo $record['id']; ?>" />	
									<input type="hidden" name="cart[<?php echo $record['id']; ?>][rowid]"  value="<?php echo $record['rowid']; ?>" />	
									<input type="hidden" name="cart[<?php echo $record['id']; ?>][name]"  value="<?php echo $record['name']; ?>" />	
									<input type="hidden" name="cart[<?php echo $record['id']; ?>][price]"  value="<?php echo $record['price']; ?>" />	
									<input type="hidden" name="cart[<?php echo $record['id']; ?>][qty]"  value="<?php echo $record['qty']; ?>" />	
					                
									
									<tr>
										<td><?php echo $k++; ?>.</td>
										<td><a href="<?php echo base_url('productdetails').'/'.$record['id'].URL_EXT; ?>"><img src="<?php echo base_url(''); ?>uploads/product/<?php echo $proImage['0']->productimagename ;?>" title="<?php echo $proImage['0']->producttitleimage ;?>" width="72" height="42"></a></td>	
										<td><a href="<?php echo base_url('productdetails').'/'.$record['id'].URL_EXT; ?>"><?php echo $record['name']; ?></a></td>	
										<td><?php echo CURRENCY.$record['price']; ?></td>	
										<td>
										<input type="text" name="cart[<?php echo $record['id']; ?>][qty]"  value="<?php echo $record['qty']; ?>" maxlength="3" size="3" />
										</td>	
										<td><?php
										   $grand_total = $grand_total + $record['subtotal']; 
										   echo CURRENCY.$record['subtotal']; ?></td>	
										<td><a href="<?php echo base_url('cartremove').'/'. $record['rowid']; ?>" title="Edit Followers"><img src="<?php echo base_url(''); ?>assets/frontend/img/remove1.jpg" title="Remove Records" width="32" height="32">Remove Item</a></td>	
											</tr>
									<?php } ?>
									
									<!--<tr> <td colspan="7">&nbsp;</td></tr>-->
									
									<tr> 
											<td colspan="2">&nbsp;</td>
											<td>&nbsp;</td>
											<td>&nbsp;</td>
											<td><b>Order Total: </b></td>
											<td><b><?php  echo CURRENCY.number_format($grand_total, 2); ?></b></td>
									        <td><a href="<?php echo base_url("cartupdate").URL_EXT; ?>"><button class="md-shoppinbutton">Update Shopping Cart</button></a></td>
									</tr>
									</form>
									
									<tr> 
											<td colspan="2"><a href="<?php echo base_url("index").URL_EXT; ?>"><button class="md-shoppinbutton">Continue Shopping </button></a></td>
											
											<td><button class="md-shoppinbutton" onClick="clear_cart()">Clear Shopping Cart</button></td>
											<td colspan="3">&nbsp;</td>
									        <td> <a href="<?php echo base_url("checkout").URL_EXT; ?>"><button class="md-shoppinbutton" style="width:174px;">Proceed Checkout </button></a></td>
									</tr>
									
                                    </tbody>
                              </table>
                            </div>
							<?php
							  } else {
							?>
							 <div class="col-lg-12"> 
							 	<div class="col-lg-3">&nbsp;</div>
								<div class="col-lg-7"><h1>Your Shopping Bag is Empty!</h1><br />
									<span style="padding-left:150px;"><img src="<?php echo base_url(''); ?>assets/frontend/img/empty-cart.png" title="Empty Cart" ></span><br/>
									<div class="col-lg-6" style="padding-top:35px; padding-left:50px;">
										<a href="<?php echo base_url("index").URL_EXT; ?>"><button class="md-primary"><span>Start Shopping</span>
										<div class="md-ripple-container" style=""></div>
										</button></a>
									</div>
								</div>
								<div class="col-lg-2">&nbsp;</div>
							 </div>
							<?php
							  }
							?>
                        </div>
						
						
                       </div>
                    </div>
		  
	   </div>	  
	   
	   
	   
	   
	   
    </div>
	</div>

<!-- Vendor --> 
<script src="<?php echo base_url('assets/frontend/js/jquery.browser.mobile.js');?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/bootstrap.js'); ?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/nanoscroller.js'); ?>"></script> 
<!-- Theme Base, Components and Settings --> 
<script src="<?php echo base_url('assets/frontend/js/theme.js'); ?>"></script> 
</body>
</html>