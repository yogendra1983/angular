<div class="right_Contact">
<div class="heading_line"></div>
<div class="about_innbox">
<div class="testimonialbox">
 <div class="testimonial1">
<?php echo $templateData['0']->description; ?>        
</div>
</div>
</div>
</div>
  </div>
         </div>