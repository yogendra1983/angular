 <script type="text/javascript" src="<?php echo base_url('assets/script/jquery.validate.min.js'); ?>"></script>
 <script src="<?php echo base_url('assets/script/formvalidation.js');?>" type="text/javascript"></script> 

<div class="products-box" style="top:1%;">
       <div class="col-sm-6">
        <h2 class="white cap trajan">order summary <?php echo $this->cart->total_items(); ?> Items</h2>
        <img src="<?php echo base_url('assets/frontend/img/title-line.PNG'); ?>">
       </div>
	   
	   <div class="row">          
		  <div class="col-lg-12" style="padding-top:10px;">				   
                      <div class="panel panel-default">
                        <div class="panel-body">			
                            
						
                        </div>
                       </div>
                    </div>		  
	   </div>	  
	   
	   
	   
	   
	   
    </div>
	</div>

<!-- Vendor --> 
<script src="<?php echo base_url('assets/frontend/js/jquery.browser.mobile.js');?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/bootstrap.js'); ?>"></script> 
<script src="<?php echo base_url('assets/frontend/js/nanoscroller.js'); ?>"></script> 
<!-- Theme Base, Components and Settings --> 
<script src="<?php echo base_url('assets/frontend/js/theme.js'); ?>"></script> 
</body>
</html>