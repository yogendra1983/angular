<p align="center" style="padding-top:200px; font-family:Arial, Helvetica, sans-serif; color:#333; font-size:24px;">

<br />
Sorry page not found, <a href="<?php echo base_url("index").URL_EXT; ?>">Jump to main page</a> </p>