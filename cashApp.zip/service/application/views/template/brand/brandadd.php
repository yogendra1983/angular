<script language="javascript">
$(document).ready(function()
   {	
   
			$("#frmbrand").validate({   
			debug: false,
			rules: {
				brandName: "required",				
			},
			messages: {
				brandName: "Please enter brand name."
				
			}
			
		});
			
			
   });
</script>

<div id="page-wrapper">
            <div class="container-fluid">
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("brand").URL_EXT; ?>">Brand Listing</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i> Add Brand
                            </li>
                        </ol>
                    </div>
                </div>
			
                <!-- Page Heading -->
				  <div class="row" style="min-height:580px;">
				  
				   <form role="form" action="" method="post" enctype="multipart/form-data" name="frmbrand" id="frmbrand">
				  
                    <div class="col-lg-6">
                        				
						   <div class="form-group">
                                <label>Brand Name <span class=red>*</span></label>
                                 <input class="form-control" name="brandName" id="brandName" placeholder="Enter Brand Name........">
								 <div class="error"><?php echo form_error('brandName'); ?></div>
                            </div>
							
							 <div class="form-group">
                                <label> Image (Max-width :500 Max-Height: 450)</label>
                                <input type="file" name="profileImage" id="profileImage">
                            </div>
							
                           <button type="submit" class="btn btn-default">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>
							
                    </div>
					
					</form>
					
					 
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>