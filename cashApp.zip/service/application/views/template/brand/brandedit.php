<script language="javascript">
$(document).ready(function()
   {	
   
			$("#frmbrand").validate({   
			debug: false,
			rules: {
				brandName: "required",				
			},
			messages: {
				brandName: "Please enter brand name."
				
			}
			
		});
			
			
   });
</script>

<div id="page-wrapper">
            <div class="container-fluid">
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("brand").URL_EXT; ?>">Brand Listing</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i> Edit Brand
                            </li>
                        </ol>
                    </div>
                </div>
			
                <!-- Page Heading -->
				  <div class="row" style="min-height:580px;">
				  
				   <form role="form" action="" method="post" enctype="multipart/form-data" name="frmbrand" id="frmbrand">
				   
				   <input type="hidden" name="brandId" value="<?php echo $brandId; ?>" />
				  
                    <div class="col-lg-6">
                        				
						   <div class="form-group">
                                <label>Brand Name <span class=red>*</span></label>
                                 <input class="form-control" name="brandName" id="brandName" value="<?php if($this->input->post('brandName')=='') echo $userData[0]->brandName; else echo $this->input->post('brandName'); ?>">
								 <div class="error"><?php echo form_error('brandName'); ?></div>
                            </div>
							
														
							
							<div class="form-group">
                               <label> Image (Max-width :500 Max-Height: 450)</label>
                                <input type="file" name="profileImage" id="profileImage">
								<div><img src="<?php echo base_url().DISPLAYBRAND.$userData[0]->image;?>" width="100" height="80" ></div>
                            </div>
							
							<button type="submit" class="btn btn-default">Submit</button>
                          
                    </div>
					</form>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>