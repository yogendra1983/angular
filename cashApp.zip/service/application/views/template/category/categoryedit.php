<script language="javascript">
$(document).ready(function()
   {	
   
			$("#frmcategory").validate({   
			debug: false,
			rules: {
				category: "required",				
			},
			messages: {
				category: "Please enter category name."
				
			}
			
		});
			
			
   });
</script>

<div id="page-wrapper">
            <div class="container-fluid">
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("category").URL_EXT; ?>">Category Listing</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i> Edit Category
                            </li>
                        </ol>
                    </div>
                </div>
			
                <!-- Page Heading -->
				  <div class="row" style="min-height:580px;">
				  
				   <form role="form" action="" method="post" enctype="multipart/form-data" name="frmcategory" id="frmcategory">
				   
				   <input type="hidden" name="categoryId" value="<?php echo $categoryId; ?>" />
				  
                    <div class="col-lg-6">
                        				
						   <div class="form-group">
                                <label>Category Name <span class=red>*</span></label>
                                 <input class="form-control" name="category" id="category" value="<?php if($this->input->post('category')=='') echo $userData[0]->category; else echo $this->input->post('category'); ?>">
								 <div class="error"><?php echo form_error('category'); ?></div>
                            </div>
							
							<div class="form-group">
                                <label>Parent Category </label>
                                
							 <select class="form-control" name="parentId" id="parentId" style="width:190px;">
								<option value="0">----Parent category ---</option>
                                     <?php foreach($categoryData as $record) {?>	 
                   						 <option value=<?php echo $record->id; ?> <?php if($userData[0]->parentId == $record->id) echo "selected"; ?>><?php  echo $record->category; ?></option> 
             						     <?php }  ?>
                                </select>
								
					        </div>							
							
							<div class="form-group">
                               <label> Image (Max-width :500 Max-Height: 450)</label>
                                <input type="file" name="profileImage" id="profileImage">
								<div><img src="<?php echo base_url().DISPLAYCATEGORY.$userData[0]->image;?>" width="100" height="80" ></div>
                            </div>
							
                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control" rows="3" name="description" id="description"><?php echo $userData[0]->description; ?></textarea>
                            </div>
                    </div>
					
					<div class="col-lg-6">
					
					       <div class="form-group">
                                <label>Meta Title </label>
                                 <input class="form-control" name="meta_title" id="meta_title" value="<?php if($this->input->post('meta_title')=='') echo $userData[0]->meta_title; else echo $this->input->post('meta_title'); ?>">
                            </div>
							
							<div class="form-group">
                                <label>Meta Keywords </label>
                                 <input class="form-control" name="meta_keyword" id="meta_keyword" value="<?php if($this->input->post('meta_keyword')=='') echo $userData[0]->meta_keyword; else echo $this->input->post('meta_keyword'); ?>">
                            </div>
							
							<div class="form-group">
                                <label>Meta Description</label>
                                <textarea class="form-control" rows="3" name="meta_description" id="meta_description"><?php echo $userData[0]->meta_description; ?></textarea>
                            </div>
							
							
							<button type="submit" class="btn btn-default">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>

                        
                    </div>
					
					
					</form>
					
					 
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>