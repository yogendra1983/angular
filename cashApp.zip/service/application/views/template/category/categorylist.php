<div id="page-wrapper">
            <div class="container-fluid">
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("category").URL_EXT; ?>">Category Listing</a>
                            </li>
                            
                        </ol>
                    </div>
                </div>
				
				  <div class="row">
				  <?php if($this->session->flashdata('message')) { ?>
				  <div class="alert alert-success">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								<strong>Success!</strong> <?Php echo $this->session->flashdata('message'); ?> 
				  </div>
				  <?php } ?>
	        
			 
	 
				  <div class="col-sm-7">&nbsp;</div>
					
					<div class="col-md-5">
						<a class="btn btn-danger mr5 mb10 itfdelete" name="delete">Delete</a>
						<a class="btn btn-success mr5 mb10 itfdelete" name="publish">Activate</a>
						<a class="btn btn-warning mr5 mb10 itfdelete" name="unpublish">Deactivate</a>
						<a href="<?php echo base_url("category/categoryadd").URL_EXT; ?>" class="btn btn-primary mr5 mb10">Add Category</a>                                    
					</div>
					

                    
                    <div class="col-lg-12" style="padding-top:10px;">
					
					
				   
                      <div class="panel panel-default">
                       
                        <!-- /.panel-heading -->
                        <div class="panel-body">
						
			<form name="frmgrouplist" id="frmitf" action="category/delete.html" method="post">
				<input type="hidden" id="itfids" name="itfids" value="" />
				<input type="hidden" id="itfaction" name="itfaction" value="" />
				
				
                            <div class="table-responsive">
                                <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th><input type="checkbox" name="itfactionevents" value="all" id="itfactionevents" class="itfrowdatas"></th>
                                            <th>No.</th>
                                            <th>Category Name</th>
                                            <th>Sub Category Name</th>
											 <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php
							
							//echo "<pre>"; print_r($aluserlist);
					          foreach ($aluserlist as $k => $record)
					          { $categoryName = $this->common_model->getcategoryNameById($record->parentId);
					         ?>	
                                    <tr>
									 <td><input type="checkbox" name="itfrowdata[]" value="<?php echo $record->id; ?>" class="itfrowdatas"></td>
									   <td><?php echo $k + 1; ?></td>  
                                        <td><?php echo $record->category; ?></td>
										<td <?php if($categoryName =='Parent') echo "style='color:#EC971F; font-weight:bold;'"; else echo "style='color:#F5CA8C; font-weight:600;'"; ?>><?php echo $categoryName ; ?></td>
										<td><?php echo ($record->status == "1") ? "<img src=".base_url('assets/sitepanel/icons/active.png')." >" : "<img src=".base_url('assets/sitepanel/icons/inactive.png').">" ?></td>										
										<td><a href="<?php echo base_url('category/categoryedit').'/'.$record->id.URL_EXT; ?>" title="Edit Record"><img src="<?php echo base_url('assets/sitepanel/dist/img/edit.png'); ?>" /></a></td>  
										
                                    </tr>
							<?php } ?>	
                                       	
                                    </tbody>
                                </table>
                            </div>
                            </div>
							
							  </form>
                            <!-- /.table-responsive -->
                        </div>
						
						<div class="col-xs-12">
							<div class="pagination">
								<?php echo $links; ?>
						</div>
	
</div>

                        <!-- /.panel-body -->
                    </div>
						
						
                    </div>
                </div>
				
				
				
				
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>