<script language="javascript">
$(document).ready(function()
   {	
			$("#frmdashboard").validate({   
			debug: false,
			rules: {
				subject: "required",
				message: "required"				
			},
			messages: {
				subject: "Please enter subject.",
				message: "Please enter message."
			}
		});
   });
</script>


 <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Dashboard
                            </li>
                        </ol>
                    </div>
                </div>
              
                <div class="row">
				
				<?php if($this->session->flashdata('message')) { ?>
				  <div class="alert alert-success">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								<strong>Success!</strong> <?Php echo $this->session->flashdata('message'); ?> 
				  </div>
				  <?php } ?>
				  
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-tasks fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div>Category Management</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo base_url("category").URL_EXT; ?>">
                                <div class="panel-footer">
                                 
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>                  
                </div>
           
			<!--	<div class="row" style="border-bottom:1px solid #eee;">
                    
                   <div class="form-group" style="border-bottom:1px solid #eee; padding-bottom:5px; font-size:17px;">
                                  <strong> Contact Administrator</strong>
                     </div>
				   
				    <div class="col-md-8">
					<form action="" method="post" name="frmdashboard" id="frmdashboard" enctype="multipart/form-data">
 					     
						 <div class="form-group">
                                <label>Subject</label>
                                <input class="form-control" name="subject" id="subject" placeholder="Enter subject........">
                            </div>
							
							
							 <div class="form-group">
                                <label>Write Your Message</label>
                                <textarea class="form-control" rows="5" name="message" id="message"></textarea>
                            </div>
							
							
						<div class="form-group">
                                <label>Attach File</label>
                                <input type="file" name="attachFile" id="attachFile">
                            </div>	
							
							<button type="submit" class="btn btn-default">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>
							
						<div class="form-group"> &nbsp;
                               
                            </div>		
							
					</form>
					
					</div> 
					
					<div class="col-lg-3 col-md-3"></div> 
                    
                </div>-->
				
				
            </div>
        </div> 