<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Catelogs</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url('assets/sitepanel/css/bootstrap.min.css'); ?>" rel="stylesheet">
   
   <!--  <link href="<?php echo base_url('assets/sitepanel/js/plugins/bootstrap/dist/css/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css">-->
	 
    <!-- Custom CSS -->
    <link href="<?php echo base_url('assets/sitepanel/css/sb-admin.css'); ?>" rel="stylesheet">
    <!-- Morris Charts CSS -->
    <link href="<?php echo base_url('assets/sitepanel/css/plugins/morris.css'); ?>" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url('assets/sitepanel/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css">
	
	
	  <link href="<?php echo base_url('assets/sitepanel/js/plugins/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css'); ?>" rel="stylesheet">
	  
	  <link href="<?php echo base_url('assets/sitepanel/js/plugins/datatables-responsive/css/dataTables.responsive.css'); ?>" rel="stylesheet">
	

<script src="<?php echo base_url('assets/script/jQuery-2.1.3.min.js'); ?>"></script>

<script type="text/javascript" src="<?php echo base_url('assets/script/jquery.validate.min.js'); ?>"></script>
 <script src="<?php echo base_url('assets/script/jsactive.js');?>" type="text/javascript"></script> 
 <script src="<?php echo base_url('assets/script/formvalidation.js');?>" type="text/javascript"></script> 


 <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url('assets/sitepanel/js/bootstrap.min.js'); ?>"></script>
	
	<script src="<?php echo base_url('assets/sitepanel/js/plugins/datatables/media/js/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/sitepanel/js/plugins/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js');?>"></script>

   
<!--calender script start here -->
<link type="text/css" href="<?php echo base_url('assets/cale/jquery.datepick.css'); ?>" rel="stylesheet">
<link type="text/css" href="<?php echo base_url('assets/cale/jquery.datetimepicker.css'); ?>" rel="stylesheet">

<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>-->
<script type="text/javascript" src="<?php echo base_url('assets/cale/jquery.datepick.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/cale/jquery.datetimepicker.js'); ?>"></script>

<script type="text/javascript">
$(function() {
	 $('#validstartdate, #validlastdate, #admissiondate, #startdatecal, #enddatecal').datetimepicker({});
});



function showDate(date) {
	alert('The date chosen is ' + date);
}
</script>

<script language="javascript">
function numbersonly(myfield, e, dec)
{
var key;
var keychar;
if (window.event)
   key = window.event.keyCode;
else if (e)
   key = e.which;
else
   return true;
keychar = String.fromCharCode(key);
if ((key==null) || (key==0) || (key==8) ||
    (key==9) || (key==13) || (key==27) )
   return true;
else if ((("+-0123456789 ").indexOf(keychar) > -1))
   return true;
else if (dec && (keychar == "."))
   {
   myfield.form.elements[dec].focus();
   return false;
   }
else
   return false;
}
</script>

  <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url("home").URL_EXT; ?>">Administrator</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $this->session->userdata['logged_in']['username']; ?>  <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="<?php echo base_url("profile/profileedit").URL_EXT; ?>"><i class="fa fa-fw fa-user"></i> Account Settings</a>
                        </li>
                      
                        <li>
                            <a href="<?php echo base_url("profile/changepassword").URL_EXT; ?>"><i class="fa fa-fw fa-gear"></i> Change Password</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="<?php echo base_url("login/logout").URL_EXT; ?>"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>