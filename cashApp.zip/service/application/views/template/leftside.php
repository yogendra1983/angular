 <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="<?php echo base_url("home").URL_EXT; ?>"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
					
					<li> <a href="<?php echo base_url("member").URL_EXT; ?>"><i class="fa fa-fw fa-edit"></i>User Management</a></li>
					
					<li> <a href="<?php echo base_url("category").URL_EXT; ?>"><i class="fa fa-fw fa-edit"></i>Category Management</a></li>
					<li> <a href="<?php echo base_url("brand").URL_EXT; ?>"><i class="fa fa-fw fa-edit"></i>Brand Management</a></li>
					
					<li> <a href="<?php echo base_url("product").URL_EXT; ?>"><i class="fa fa-fw fa-edit"></i>Product Management</a></li>
					
					<li> <a href="<?php echo base_url("order").URL_EXT; ?>"><i class="fa fa-bars"></i> Order Management</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
			
			</nav>