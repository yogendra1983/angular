<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>EPL Login </title>
	 <link href="<?php echo base_url('assets/sitepanel/dist/css/style.css');?>" rel="stylesheet" type="text/css" />
  </head>
   <script src="<?php echo base_url('assets/script/jQuery-2.1.3.min.js');?>" type="text/javascript"></script> 
  <script src="<?php echo base_url('assets/script/jquery-ui.min.js');?>" type="text/javascript"></script> 
  <script type="text/javascript" src="<?php echo base_url('assets/script/jquery.validate.min.js'); ?>"></script>
  
  <script>
$(document).ready(function()
   {
		 $("#loginform").validate({ 
			debug: false,
			rules: {
				username: "required",
				password: "required"					
			},
			messages: {
				username: "Please enter email id.",
				password: "Please enter password."				
			}
			
		});
		
   });
</script>
  
  <body>

<div class='form aniamted bounceIn'>
  <div class='login'>
    <h2>Account Login Panel</h2>
	<span style="font-size:12px; color:#990000;"><?php  echo $invalidupass; ?> </span> 
    <form method="post" action="" name="loginform" id="loginform">
	
      <input type="text" name="username" id="username" placeholder="Email Id">
	  
	   <div class="error"> <?php echo form_error('username'); ?></div>
	   
      <input type="password" name="password" id="password" placeholder="Password">
	  
	  <div class="error"> <?php echo form_error('password'); ?></div>
	  
      <button>Login</button>
	  
    </form>
  </div>
  
  <footer>
  <!--alertevents.com-->
   <!-- <a href='http://andytran.me'>Forgot Password?</a>-->
  </footer>
</div>
    
  </body>
</html>