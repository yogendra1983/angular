<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Edu viewers </title>
	 <link href="<?php echo base_url('assets/sitepanel/dist/css/style.css');?>" rel="stylesheet" type="text/css" />
  </head>
  <body>

<div>
<div style="float:left; margin:50px 0 0 150px;background-color:#9DE699; width:540px; line-height:40px; border-bottom:1px solid #bacdb7; border-top:1px solid #bacdb7;"><span style="font-size:18px;color:#ffffff; font-weight:bold;">You have successfully Logged out of Edu viewers
       <a href="<?php echo base_url('login').URL_EXT; ?>" style="font-size:13px; color:#372760;">Login Again</a></span></div>
  <footer>
   <!-- <a href='http://andytran.me'>Forgot Password?</a>-->
  </footer>
</div>
    
  </body>
</html>