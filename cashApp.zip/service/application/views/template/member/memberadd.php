<div id="page-wrapper">

            <div class="container-fluid">
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("member").URL_EXT; ?>">User Listing</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i> Add User
                            </li>
                        </ol>
                    </div>
                </div>
				
                <!-- Page Heading -->
				 <form role="form" action="" method="post" enctype="multipart/form-data" name="userform" id="userform">
				  <div class="row">
                    <div class="col-lg-6">				    
                       
                         
						   <div class="form-group">
                                <label>User Name</label>
                                <input class="form-control" name="username" id="username" placeholder="Enter User Name........">
								<div class="error"><?php echo form_error('username'); ?></div> 
                            </div>
							
							<div class="form-group">
                                <label>User EmailId (Use for Login )</label>
                                <input class="form-control" name="userEmailId" id="userEmailId" placeholder="Enter User EmailId.......">
								<div class="error"><?php echo form_error('userEmailId'); ?></div> 
                            </div>
							<div class="form-group">
                                <label>User Password</label>
                                <input class="form-control" name="userPassword" id="userPassword" type="password" placeholder="User Password.........">
								<div class="error"><?php echo form_error('userPassword'); ?></div> 
                            </div>
							<div class="form-group">
                                <label>Organization Nmae</label>
                                <input class="form-control" name="companyname" id="companyname" placeholder="Organization Nmae......">
                            </div>
							<div class="form-group">
                                <label>Email Id</label>
                                <input class="form-control" name="emailId" id="emailId" placeholder="Enter Email Id.......">
                            </div>
							<div class="form-group">
                                <label>Contact Number</label>
                                <input class="form-control" name="contactno" id="contactno" placeholder="Enter Contact Number........">
                            </div>
							
							<div class="form-group">
                                <label>Mobile Number</label>
                                <input class="form-control" name="mobile" id="mobile" placeholder="Enter mobile........">
                            </div>
							<div class="form-group">
                                <label>Address</label>
                                <input class="form-control" name="address" id="address" placeholder="Enter address Number........">
                            </div>
					
                    </div>
					
					
					
					 <div class="col-lg-6">
                      
					   <div class="form-group">
                                <label>Country</label>
								<select name="comcountry" id="comcountry" class="form-control" style="width:200px;">
										<option value=""4>-------------India-----------</option>
									</select>
									
                            </div>
					       <div class="form-group">
                                <label>State</label>
								<select name="state" id="state" class="form-control" style="width:200px;">
										 <?php foreach($statelistdis as $record) {?>	 
                   						 <option value=<?php echo $record->state_id; ?>><?php  echo $record->state_name; ?></option> 
             						     <?php }  ?>	
									</select>
									
                            </div>
					<div class="form-group">
                                <label>City</label>
                                <input class="form-control" name="city" id="city" placeholder="Enter city........">
                            </div>
							
							<div class="form-group">
                                <label>Validity Start Date</label>
                                <input class="form-control" name="validefrom" id="validstartdate" placeholder="Validity Start Date....." style="width:200px;">
                            </div>
							
							<div class="form-group">
                                <label>Validity End Date</label>
                                <input class="form-control" name="validetill" id="validlastdate" placeholder="Validity End Date......" style="width:200px;">
                            </div>
							
							<div class="form-group">
                                <label>Vender Name </label>
                                <input class="form-control" name="venderName" id="venderName" placeholder="Enter Vender Name.......">
                            </div>
							
							<div class="form-group">
                                <label>Sender Id</label>
                                <input class="form-control" name="sendderid" id="sendderid" placeholder="Enter Sender Id.......">
                            </div>
							
                            <button type="submit" class="btn btn-default">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>

                     

                  
                    </div>
                </div>
				   </form>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>