<div id="page-wrapper">

            <div class="container-fluid">
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("member").URL_EXT; ?>">User Listing</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i>Edit User  
                            </li>
                        </ol>
                    </div>
                </div>
				
				
                <!-- Page Heading -->
				
						
				  <div class="row">
                    <div class="col-lg-6">
						    
                        <form role="form" action="" method="post" enctype="multipart/form-data" name="frmuser" id="frmuser">
						<input type="hidden" name="userId" value="<?php echo $userId; ?>" />
                         
						   <div class="form-group">
                                <label>User Name</label>
                                <input class="form-control" name="username" id="username" value="<?php if($this->input->post('username')=='') echo $userData[0]->username; else echo $this->input->post('username'); ?>">
								<div class="error"><?php echo form_error('username'); ?></div> 
                            </div>
							
							<div class="form-group">
                                <label>User EmailId (Use for Login )</label>
                                <input class="form-control" name="loginid" id="loginid" readonly value="<?php if($this->input->post('loginid')=='') echo $userData[0]->loginid; else echo $this->input->post('loginid'); ?>">
								
                            </div>
							
							<div class="form-group">
                                <label>Email Id</label>
                                <input class="form-control" name="emailid" id="emailid" value="<?php if($this->input->post('emailid')=='') echo $userData[0]->emailid; else echo $this->input->post('emailid'); ?>">
                            </div>
							
							<div class="form-group">
                                <label>Address</label>
                                <input class="form-control" name="address" id="address" value="<?php if($this->input->post('address')=='') echo $userData[0]->address; else echo $this->input->post('address'); ?>">
                            </div>
							
							
							<div class="form-group">
                                <label>Land Mark</label>
                                <input class="form-control" name="landmark" id="landmark" value="<?php if($this->input->post('landmark')=='') echo $userData[0]->landmark; else echo $this->input->post('landmark'); ?>">
                            </div>
							
							
							<div class="form-group">
                                <label>pincode</label>
                                <input class="form-control" name="pincode" id="pincode" value="<?php if($this->input->post('pincode')=='') echo $userData[0]->pincode; else echo $this->input->post('pincode'); ?>">
                            </div>
							
							<div class="form-group">
                                <label>Country</label>
                                <input class="form-control" name="country" id="country" value="<?php if($this->input->post('country')=='') echo $userData[0]->country; else echo $this->input->post('country'); ?>">
                            </div>
							
							<div class="form-group">
                                <label>State</label>
                                <input class="form-control" name="state" id="state" value="<?php if($this->input->post('state')=='') echo $userData[0]->state; else echo $this->input->post('state'); ?>">
                            </div>
							
							<div class="form-group">
                                <label>Phone</label>
                                <input class="form-control" name="phone" id="phone" value="<?php if($this->input->post('phone')=='') echo $userData[0]->phone; else echo $this->input->post('phone'); ?>">
                            </div>
							</form>
                    </div>
					
					
					 
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>