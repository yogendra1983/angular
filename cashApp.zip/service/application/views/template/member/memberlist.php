   <div id="page-wrapper">
            <div class="container-fluid">
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("member").URL_EXT; ?>">User Listing</a>
                            </li>
                            
                        </ol>
                    </div>
                </div>
				
				 <div class="row">
				  <?php if($this->session->flashdata('message')) { ?>
				  <div class="alert alert-success">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								<strong>Success!</strong> <?Php echo $this->session->flashdata('message'); ?> 
				  </div>
				  <?php } ?>
				  
				  
				  <div class="col-sm-9">
				  
				  <form name="frmsearch" id="" action="" method="post">
						 <div class="input-group mb15 col-sm-5">
							<input type="text" name="q" id="txtsearch" class="form-control" value="<?php echo isset($frm_data["q"])?$frm_data["q"]:""; ?>" />
								<span class="input-group-btn">
								<button type="submit" name="btnsearch" id="btnsearch" class="btn btn-primary">Search</button>
								</span>
						 </div>
						 
					</form>
						 
					</div>
					
					<div class="col-md-3">
						<a class="btn btn-danger mr5 mb10 itfdelete" name="delete">Delete</a>
						<a class="btn btn-success mr5 mb10 itfdelete" name="publish">Activate</a>
						<a class="btn btn-warning mr5 mb10 itfdelete" name="unpublish">Deactivate</a>
					</div>
					
			
			
						  <div class="col-lg-12" style="padding-top:10px;">
					
					
				   
                      <div class="panel panel-default">
                       
                        <!-- /.panel-heading -->
                        <div class="panel-body">
						
			<form name="frmgrouplist" id="frmitf" action="registeruser/delete.html" method="post">
				<input type="hidden" id="itfids" name="itfids" value="" />
				<input type="hidden" id="itfaction" name="itfaction" value="" />
				
				
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
										<th width="25"><input type="checkbox" name="itfactionevents" value="all" id="itfactionevents" class="itfrowdatas"></th>
									    <th width="56" height="25">No.</td>
                                        <th width="397">User Name </th>
                                        <th width="421">Email Id</th>
                                        <th width="264">Phone</th>
										<th width="42">Status</th>			
										<th width="77">Action</th>
										
                                    </tr>
                                    </thead>
                                    <tbody>
									<?php
							
							//echo "<pre>"; print_r($campaignTimeReport);
					          foreach ($allmember as $k => $record)
					          { 
					         ?>	
                                    <tr>
									<td><input type="checkbox" name="itfrowdata[]" value="<?php echo $record->memid; ?>" class="itfrowdatas"></td>
									   <td><?php echo $k + 1; ?></td>  
                                        <td><?php echo $record->username; ?></td>
                                        <td><?php echo $record->emailid; ?></td>
										<td><?php echo $record->phone; ?></td>
										<td><?php echo ($record->status == "1") ? "<img src=".base_url('assets/sitepanel/icons/active.png')." >" : "<img src=".base_url('assets/sitepanel/icons/inactive.png').">" ?></td>	
										<td width="77"><a href="<?php echo base_url('member/memberview').'/'.$record->memid.URL_EXT; ?>" title="View Record"><img src="<?php echo base_url('assets/sitepanel/dist/img/edit.png'); ?>" /></a></td>
                                    </tr>
							<?php } ?>	
							
                                    </tbody>
                                </table>
                            </div>
							
							  </form>
                            <!-- /.table-responsive -->
                        </div>
						
						<div class="col-xs-12">
							<div class="pagination">
								<?php echo $links; ?>
						</div>
	
</div>

                        <!-- /.panel-body -->
                    </div>
						
						
                    </div>
					
					

            </div>
            <!-- /.container-fluid -->

        </div>