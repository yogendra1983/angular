<script language="javascript">
$(document).ready(function()
   {	
			$("#frmproduct").validate({   
			debug: false,
			rules: {
				name: "required",
				category: "required",
				code: "required",
				price: "required",
				quantity: "required"
			},
			messages: {
				name: "Please enter product name.",
				category: "Please select category.",
				code: "Please enter product code.",
				price: "Please enter product price.",
				quantity: "Please enter quantity."
			}
			
		});
			
			
   });
</script>

<div id="page-wrapper">
            <div class="container-fluid">
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("product").URL_EXT; ?>">Product Listing</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i> Edit Product
                            </li>
                        </ol>
                    </div>
                </div>
			
                <!-- Page Heading -->
				 <form role="form" action="" method="post" enctype="multipart/form-data" name="frmproduct" id="frmproduct">
				  <input type="hidden" name="pid" value="<?php echo $pid; ?>" />
				  
				  <div class="row">
				  
                    <div class="col-lg-6">
                        				
						   <div class="form-group">
                                <label>Product Name <span class=red>*</span></label>
                                 <input class="form-control" name="name" id="name" value="<?php if($this->input->post('name')=='') echo $userData[0]->name; else echo $this->input->post('name'); ?>">
								 <div class="error"><?php echo form_error('name'); ?></div>
                            </div>
							
							<div class="form-group">
                                <label>Category Name <span class=red>*</span></label>
                      <select class="form-control" name="category" id="category">
                     
                      <option value="" selected="selected" style="background-image:none !important;">-----------------select category name------------</option>
					<?php foreach($categoryData as $categoryId) {?>
							<option value="<?php echo $categoryId->id;?>"<?php if($userData[0]->cid == $categoryId->id) echo "selected"; ?>><?php echo $categoryId->category; ?></option>		
					<?php } ?>					 
                        </select> 
								 <div class="error"><?php echo form_error('category'); ?></div>
                            </div>
							
							
							<!--<div class="form-group">
                                <label>Category Name <span class=red>*</span></label>
                      <select class="form-control" name="category" id="category">
                     
                      <option value="" selected="selected" style="background-image:none !important;">-----------------select category name------------</option>
                       <?php foreach($categoryData as $categoryId) {?>	
                        <optgroup label="<?php echo $categoryId->category;?>">
                                               
					   <?php  $subCategory = $this->common_model->get_subcategory($categoryId->id); foreach($subCategory as $categoryIdSub) {  ?>
                       
                        <option value="<?php echo $categoryIdSub->id;?>"<?php if($userData[0]->cid == $categoryIdSub->id) echo "selected"; ?>><?php echo $categoryIdSub->category; ?></option>
                        
							<?php } ?>
                           </optgroup> 
						   <?php } ?>					 
                        </select> 
								 <div class="error"><?php echo form_error('category'); ?></div>
                            </div>-->
							
		<div class="form-group">
			<label>Brand Name </label>
			<select class="form-control" name="brandId" id="brandId">
			
			<option value="" selected="selected" style="background-image:none !important;">-----------------select Brand name------------</option>
			<?php foreach($brandData as $record) {?>	
			
			<option value="<?php echo $record->brandId;?>" <?php if($record->brandId == $userData[0]->brandId) echo "selected"; ?> ><?php echo $record->brandName; ?></option>
			
			<?php } ?>
			</select> 
		</div>
							
							
						<div class="form-group">
                                <label>Code<span class=red>*</span></label>
                                 <input class="form-control" style="width:180px;" name="code" id="code" value="<?php if($this->input->post('code')=='') echo $userData[0]->code; else echo $this->input->post('code'); ?>">
								 <div class="error"><?php echo form_error('code'); ?></div>
                        </div>	
						
						<div class="form-group">
                                <label>Price<span class=red>*</span></label>
                                 <input class="form-control" style="width:180px;" name="price" id="price" value="<?php if($this->input->post('price')=='') echo $userData[0]->price; else echo $this->input->post('price'); ?>">
								 <div class="error"><?php echo form_error('price'); ?></div>
                        </div>	
						
						<div class="form-group">
                                <label>Discount</label>
                                 <input class="form-control" style="width:180px;" name="discountprice" id="discountprice" value="<?php if($this->input->post('discountprice')=='') echo $userData[0]->discountprice; else echo $this->input->post('discountprice'); ?>">
                        </div>
						
						<div class="form-group">
                                <label>Weight</label>
                                 <input class="form-control" style="width:180px;" name="weight" id="weight" value="<?php if($this->input->post('weight')=='') echo $userData[0]->weight; else echo $this->input->post('weight'); ?>">
                        </div>
							
                    </div>
					
					<div class="col-lg-6">
					
					<div class="form-group">
                                <label>Size</label>
                                 <input class="form-control" style="width:180px;" name="size" id="size" value="<?php if($this->input->post('weight')=='') echo $userData[0]->weight; else echo $this->input->post('weight'); ?>">
                        </div>
						<div class="form-group">
                                <label>Color</label>
                                 <input class="form-control" style="width:180px;" name="color" id="color" value="<?php if($this->input->post('color')=='') echo $userData[0]->color; else echo $this->input->post('color'); ?>">
                        </div>
						
					
					   <div class="form-group">
                                <label>Quantity <span class=red>*</span></label>
                                 <input class="form-control" style="width:180px;" name="quantity" id="quantity" value="<?php if($this->input->post('quantity')=='') echo $userData[0]->quantity; else echo $this->input->post('quantity'); ?>">
                        </div>	
						
						
						
						<div class="form-group">
                                <label>Featured &nbsp;&nbsp;</label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="featured" value="1" <?php if(($userData[0]->featured) == 1) echo "checked"; ?>>&nbsp;
                                </label>
                             
                            </div>
							
							
							<div class="form-group">
                                <label>Exclusive &nbsp;&nbsp;</label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="exclusive" value="1" <?php if(($userData[0]->exclusive) == 1) echo "checked"; ?>>&nbsp;
                                </label>
                             
                            </div>
							
							<div class="form-group">
                                <label>Newlaunch &nbsp;&nbsp;</label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="newlaunch" value="1" <?php if(($userData[0]->newlaunch) == 1) echo "checked"; ?>>&nbsp;
                                </label>
                             
                            </div>
							
							<div class="form-group">
                                <label>Onsale &nbsp;</label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" name="onsale" value="1" <?php if(($userData[0]->onsale) == 1) echo "checked"; ?>>&nbsp;
                                </label>
                             
                            </div>						
						
						
						<div class="form-group">
                                <label>Short Description</label>
                                <textarea class="form-control" rows="2" name="shortdes" id="shortdes"><?php echo $userData[0]->shortdes; ?></textarea>
                            </div>
                    </div>
					
                </div>
				
				  <div class="col-lg-12">
				            <div class="form-group">
                                <label>Product Description</label>
                                <textarea class="form-control" rows="4" name="productdes" id="productdes"><?php echo $userData[0]->productdes; ?></textarea>
                            </div>
							
							<div class="form-group">
                                <label>Measurement Description</label>
                                <textarea class="form-control" rows="4" name="measurement" id="measurement"><?php echo $userData[0]->measurement; ?></textarea>
                            </div>
							
							<div class="form-group">
                                <label>Material Info Description</label>
                                <textarea class="form-control" rows="4" name="material" id="material"><?php echo $userData[0]->material; ?></textarea>
                            </div>
							
							<div class="form-group">
                                <label>Meta Title </label>
                                 <input class="form-control" name="meta_title" id="meta_title" value="<?php if($this->input->post('meta_title')=='') echo $userData[0]->meta_title; else echo $this->input->post('meta_title'); ?>">
                            </div>
							<div class="form-group">
                                <label>Meta Keywords </label>
                                 <input class="form-control" name="meta_keyword" id="meta_keyword" value="<?php if($this->input->post('meta_keyword')=='') echo $userData[0]->meta_keyword; else echo $this->input->post('meta_keyword'); ?>">
                            </div>
							
							<div class="form-group">
                                <label>Meta Description</label>
                                <textarea class="form-control" rows="2" name="meta_description" id="meta_description"><?php echo $userData[0]->meta_description; ?></textarea>
                            </div>
							
							<button type="submit" class="btn btn-default">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>
				  </div>
				  
				  </form>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>