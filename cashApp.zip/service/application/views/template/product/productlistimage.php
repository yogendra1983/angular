<div id="page-wrapper">
            <div class="container-fluid">
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("product").URL_EXT; ?>">Product Listing</a>
                            </li>
							
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i> Product Image Listing
                            </li>
                            
                        </ol>
                    </div>
                </div>
				
				  <div class="row">
				  <?php if($this->session->flashdata('message')) { ?>
				  <div class="alert alert-success">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								<strong>Success!</strong> <?Php echo $this->session->flashdata('message'); ?> 
				  </div>
				  <?php } ?>
	        
			 
	 
				  <div class="col-sm-7">Product Name : <?php echo $this->common_model->getProductName($productimageId); ?></div>
					
					<div class="col-md-5">
						<a class="btn btn-danger mr5 mb10 itfdelete" name="delete">Delete</a>
						<a class="btn btn-success mr5 mb10 itfdelete" name="publish">Activate</a>
						<a class="btn btn-warning mr5 mb10 itfdelete" name="unpublish">Deactivate</a>
						<a href="<?php echo base_url("product/productimageadd").'/'.$productimageId.URL_EXT; ?>" class="btn btn-primary mr5 mb10">Add Product Image</a>                                    
					</div>
					

                    
                    <div class="col-lg-12" style="padding-top:10px;">
					
					
				   
                      <div class="panel panel-default">
                       
                        <!-- /.panel-heading -->
                        <div class="panel-body">  
						
			<form name="frmgrouplist" id="frmitf" action="<?php echo base_url('product/deleteimage').URL_EXT; ?>" method="post">
				<input type="hidden" id="itfids" name="itfids" value="" />
				<input type="hidden" id="productid" name="productid" value="<?php echo $productimageId; ?>" />
				<input type="hidden" id="itfaction" name="itfaction" value="" />
				
				
                            <div class="table-responsive">
                                <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                          <th width="20"><input type="checkbox" name="itfactionevents" value="all" id="itfactionevents" class="itfrowdatas"></th>
                                            <th width="24">No.</th>
                                             <th width="669">Image Title</th>
                                             <th width="195">Image </th>
											 <th width="80">Status</th>
                                            <th width="55">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php
							
							//echo "<pre>"; print_r($aluserlist);
					          foreach ($allproductImage as $k => $record)
					          { 
					         ?>	
                                    <tr>
									 <td><input type="checkbox" name="itfrowdata[]" value="<?php echo $record->pimageId; ?>" class="itfrowdatas"></td>
									   <td><?php echo $k + 1; ?></td>  
                                        <td><?php echo $record->producttitleimage; ?></td>
										<td><img src="<?php echo base_url().DISPLAYPRODUCT.$record->productimagename;?>" width="56" height="41" ></td>
										
										<td><?php echo ($record->status == "1") ? "<img src=".base_url('assets/sitepanel/icons/active.png')." >" : "<img src=".base_url('assets/sitepanel/icons/inactive.png').">" ?></td>
																								
										<td><a href="<?php echo base_url('product/productimageedit').'/'.$record->pid.'/'.$record->pimageId.URL_EXT; ?>" title="Edit Record"><img src="<?php echo base_url('assets/sitepanel/dist/img/edit.png'); ?>" /></a></td>  
										
                                    </tr>
							<?php } ?>	
                                       	
                                    </tbody>
                                </table>
                            </div>
                            </div>
							
							  </form>
                            <!-- /.table-responsive -->
                        </div>
						
						
                        <!-- /.panel-body -->
                    </div>
						
						
                    </div>
                </div>
				
				
				
				
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>