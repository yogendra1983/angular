<script language="javascript">
$(document).ready(function()
   {	
			$("#frmproductimage").validate({   
			debug: false,
			rules: {
				producttitleimage: "required"
			},
			messages: {
				producttitleimage: "Please enter product image title."
			}
			
		});
			
			
   });
</script>

<div id="page-wrapper">
            <div class="container-fluid">
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("product").URL_EXT; ?>">Product</a>
                            </li>
							
							<li>
                               <i class="fa fa-fw fa-edit"></i>  <a href="<?php echo base_url("product/productimage").'/'.$productimageId.URL_EXT; ?>">Product Image Listing</a>
                            </li>
							
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i> Add Product Image <?php echo $prodImageData[0]->producttitleimage; ?>
                            </li>
                        </ol>
                    </div>
                </div>
			
                <!-- Page Heading -->
				 <form role="form" action="" method="post" name="frmproductimage" id="frmproductimage"  enctype="multipart/form-data">
				 
				 <input type="hidden" name="productimageId" value="<?php echo $productimageId; ?>" />
				  <input type="hidden" name="imageId" value="<?php echo $imageId; ?>" />
				  
				  
				  <div class="row">
				  
                    <div class="col-lg-6">
                        				
						   <div class="form-group">
                                <label>Product Image Tile <span class=red>*</span></label>
                                 <input class="form-control" name="producttitleimage" id="producttitleimage" value="<?php if($this->input->post('producttitleimage')=='') echo $prodImageData[0]->producttitleimage; else echo $this->input->post('producttitleimage'); ?>" >
								 <div class="error"><?php echo form_error('producttitleimage'); ?></div>
                            </div>
							
						<div class="form-group">
                                <label>Product Image(Max-width :600 Max-Height: 400)</label>
                                <input type="file" name="productimagename" id="productimagename">
								<div><img src="<?php echo base_url().DISPLAYPRODUCT.$prodImageData[0]->productimagename;?>" width="100" height="80" ></div>
                            </div>
						    <button type="submit" class="btn btn-default">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>
                    </div>
                </div>
				  </form>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>