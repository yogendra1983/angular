<div id="page-wrapper">

            <div class="container-fluid">
			
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("home").URL_EXT; ?>"> Change Password  </a>
                            </li>
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i> Edit User Password
                            </li>
                        </ol>
                    </div>
                </div>
				
				
                <!-- Page Heading -->
				
						
				  <div class="row" style="min-height:580px;">
                    <div class="col-lg-6">
						
						<div style="border-bottom-color:#FF6600 !important;">&nbsp;</div>
						    
                       <form action="" method="post" name="form1"  enctype="multipart/form-data" class="form-horizontal ucase">
						<input type="hidden" name="userId" value="<?php echo $userId; ?>" />
                         
						   <div class="form-group">
                                <label>Old Password</label>
                                <input class="form-control" name="oldpassword" id="oldpassword" value="" type="password">
								<div class="error"><?php if(isset($match_old_pass)) { echo $match_old_pass; } ?><?php echo form_error('oldpassword'); ?></div> 
                            </div>
							
							<div class="form-group">
                                <label>New Password</label>
                                <input class="form-control" name="newpassword" id="newpassword" value="" type="password">
								<div class="error"><?php if(isset($match_both_pass)) { echo $match_both_pass; } ?><?php echo form_error('newpassword'); ?></div> 
                            </div>
							
							<div class="form-group">
                                <label>Confirm Password</label>
                                <input class="form-control" name="confirmpassword" id="confirmpassword" value="" type="password">
								<div class="error"><?php if(isset($match_both_pass)) { echo $match_both_pass; } ?><?php echo form_error('confirmpassword'); ?></div> 
                            </div>
							
						    <button type="submit" class="btn btn-default">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>

                        </form>	
					
                    </div>
					
					
					 
					
					
					
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>