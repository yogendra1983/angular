<div id="page-wrapper">

            <div class="container-fluid">
			
			
			<div class="row">
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li>
                               <i class="fa fa-desktop"></i> <a href="<?php echo base_url("home").URL_EXT; ?>">  Account Settings</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-fw fa-edit"></i> Edit User Profile
                            </li>
                        </ol>
                    </div>
                </div>
				
				
                <!-- Page Heading -->
				
						
				  <div class="row" style="min-height:580px;">
                    <div class="col-lg-6">
						
						<div style="border-bottom-color:#FF6600 !important;">&nbsp;</div>
						    
                        <form role="form" action="" method="post" enctype="multipart/form-data" name="frmuser" id="frmuser">
						<input type="hidden" name="userId" value="<?php echo $userId; ?>" />
                         
						   <div class="form-group">
                                <label>User Name</label>
                                <input class="form-control" name="username" id="username" value="<?php if($this->input->post('companyname')=='') echo $userData[0]->username; else echo $this->input->post('username'); ?>">
								<div class="error"><?php echo form_error('username'); ?></div> 
                            </div>
							
							<div class="form-group">
                                <label>User EmailId (Use for Login )</label>
                                <input class="form-control" name="userEmailId" id="userEmailId" readonly value="<?php if($this->input->post('userEmailId')=='') echo $userData[0]->userEmailId; else echo $this->input->post('userEmailId'); ?>">
								
                            </div>
							
							<div class="form-group">
                                <label>Organization Nmae</label>
                                <input class="form-control" name="companyname" id="companyname" value="<?php if($this->input->post('companyname')=='') echo $userData[0]->companyname; else echo $this->input->post('companyname'); ?>">
                            </div>
							<div class="form-group">
                                <label>Email Id</label>
                                <input class="form-control" name="emailId" id="emailId" value="<?php if($this->input->post('emailId')=='') echo $userData[0]->emailId; else echo $this->input->post('emailId'); ?>">
                            </div>
							
							
							
							<div class="form-group">
                                <label>Mobile Number</label>
                                <input class="form-control" name="mobile" id="mobile" value="<?php if($this->input->post('mobile')=='') echo $userData[0]->mobile; else echo $this->input->post('mobile'); ?>">
                            </div>
							
					
                    </div>
					
					
					 <div class="col-lg-6">
						<div style="width:100%;">
								<div style="float:leftl; width:100%; height:10px;">&nbsp;</div>
						</div>					
						
						<div style="border-bottom-color:#FF6600 !important;">&nbsp;</div>
				          
                      
					  
					 
							<div class="form-group">
                                <label>Address</label>
                                <input class="form-control" name="address" id="address" value="<?php if($this->input->post('address')=='') echo $userData[0]->address; else echo $this->input->post('address'); ?>">
                            </div>
							
					   <div class="form-group">
                                <label>Country</label>
								<select name="comcountry" id="comcountry" class="form-control" style="width:200px;">
										<option value=""4>-------------India-----------</option>
									</select>
									
                            </div>
<div class="form-group">
	<label>State</label>	
<input class="form-control" name="state" id="state" value="<?php if($this->input->post('state')=='') echo $userData[0]->state; else echo $this->input->post('state'); ?>">
</div>
					<div class="form-group">
                                <label>City</label>
                                <input class="form-control" name="city" id="city" value="<?php if($this->input->post('city')=='') echo $userData[0]->city; else echo $this->input->post('city'); ?>">
                            </div>
							
							<div class="form-group">
                                <label>Message</label>
                                <textarea class="form-control" name="sendmessage" id="sendmessage"><?php echo $userData[0]->sendmessage; ?></textarea>
                            </div>
							
							
							
                            <button type="submit" class="btn btn-default">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>

                        </form>

                  
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>