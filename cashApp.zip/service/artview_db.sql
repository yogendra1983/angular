-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2018 at 08:32 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `artview_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `parentId` int(11) NOT NULL DEFAULT '0' COMMENT '0 parent',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 inactive, 1 active',
  `sort` int(11) NOT NULL DEFAULT '0',
  `meta_title` varchar(100) NOT NULL,
  `meta_keyword` varchar(300) NOT NULL,
  `meta_description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`, `image`, `description`, `parentId`, `status`, `sort`, `meta_title`, `meta_keyword`, `meta_description`) VALUES
(1, 'Kurties', '', '', 0, 1, 0, 'Kurties', 'Kurties', 'Kurties'),
(2, 'Lehnga', '', '', 0, 1, 0, 'Lehnga', 'Lehnga', 'Lehnga'),
(3, 'Gowns', '', '', 0, 1, 0, 'Gowns', 'Gowns', 'Gowns'),
(4, 'Anarkali', '', '', 0, 1, 0, 'Anarkali', 'Anarkali', 'Anarkali'),
(5, 'Suits', '', '', 0, 1, 0, 'Suits', 'Suits', 'Suits');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customerId` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL,
  `state` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerId`, `username`, `address1`, `address2`, `state`, `city`, `pincode`, `phone`, `emailid`, `createDate`) VALUES
(6, 'yogendra kumar', 'ashok nager', 'ashok nager', 'delhi', 'Delhi', '110096', '9015992826', 'php.yogendra@gmail.com', '2016-03-18 09:27:37');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `memid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `loginid` varchar(255) NOT NULL,
  `password` varchar(200) NOT NULL,
  `emailid` varchar(200) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `landmark` varchar(255) NOT NULL,
  `country` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`memid`, `username`, `loginid`, `password`, `emailid`, `pincode`, `address`, `landmark`, `country`, `state`, `phone`, `status`, `createDate`) VALUES
(1, 'yogendra singh', 'php.yogendra@gmail.com', 'e6e061838856bf47e1de730719fb2609', 'php.yogendra@gmail.com', '110096', 'A-204, New Ashok Nagar, Delhi-96', 'Ashok Bihar', '', '', '9015992826', '1', '2015-12-10 11:58:49');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `orderId` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paymenttype` varchar(100) NOT NULL,
  `totalpayment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`orderId`, `customerId`, `createDate`, `paymenttype`, `totalpayment`) VALUES
(3, 6, '2016-03-18 09:27:38', 'onlinepayment', '600');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `ordetailId` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `orderId` int(11) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` float NOT NULL,
  `customerId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`ordetailId`, `productid`, `orderId`, `productname`, `quantity`, `price`, `customerId`) VALUES
(2, 9, 3, 'White Bridal Gown', 1, 250, 6),
(3, 8, 3, 'Black Bridal Gown', 1, 350, 6);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `discountprice` varchar(100) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `size` varchar(50) NOT NULL,
  `color` varchar(100) NOT NULL,
  `quantity` int(10) NOT NULL,
  `sort` int(11) NOT NULL,
  `featured` int(2) NOT NULL DEFAULT '0',
  `exclusive` int(2) NOT NULL DEFAULT '0',
  `newlaunch` int(2) NOT NULL DEFAULT '0',
  `onsale` int(2) NOT NULL DEFAULT '0',
  `code` varchar(255) NOT NULL,
  `price` varchar(100) NOT NULL,
  `shortdes` text NOT NULL,
  `productdes` text NOT NULL,
  `measurement` text NOT NULL,
  `material` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `meta_description` text NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `cid`, `brandId`, `name`, `discountprice`, `weight`, `size`, `color`, `quantity`, `sort`, `featured`, `exclusive`, `newlaunch`, `onsale`, `code`, `price`, `shortdes`, `productdes`, `measurement`, `material`, `meta_title`, `meta_keyword`, `meta_description`, `status`) VALUES
(8, 1, 0, 'Black Bridal Gown', '', '', '', '', 150, 0, 0, 0, 1, 0, 'PRO12', '350', 'Black Bridal Gown', 'Black Bridal Gown', '', '', 'Black Bridal Gown', 'Black Bridal Gown', 'Black Bridal Gown', 1),
(9, 1, 4, 'White Bridal Gown', '', '', '', 'blue', 150, 0, 0, 0, 1, 0, '1478', '250', 'Silk Skirt<br>\r\n Magenta silk lamhe skirt<br>\r\nColorful embroidery on waist band and bottom sweep<br>\r\n Red edging on the bottom<br>\r\nHook and zip fastening<br>', 'This product cannot be returned or exchanged\r\nFINAL SALE\r\nMinor alterations in measurements are possible.\r\nKindly contact us at contact@artview.com post placing the order and we will get in touch with you.\r\nTo be shipped in 10-12 working days', 'M - Length-38 ½\",\r\nWaist-32”,\r\nHip-NA,\r\nBottom-7mtrs', 'Silk', 'Meta Title ', 'Meta Keywords ', 'Meta Description', 1);

-- --------------------------------------------------------

--
-- Table structure for table `productimage`
--

CREATE TABLE `productimage` (
  `pimageId` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `producttitleimage` varchar(255) NOT NULL,
  `productimagename` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productimage`
--

INSERT INTO `productimage` (`pimageId`, `pid`, `producttitleimage`, `productimagename`, `status`) VALUES
(7, 9, 'White Bridal Gown', 'product-1.PNG', '1'),
(9, 8, 'Black Bridal Gown', 'product-2.PNG', '1'),
(10, 9, 'White Bridal', 'pic1.JPG', '1'),
(11, 9, 'White Bridal 2', 'product-21.PNG', '1'),
(12, 9, 'White Bridal 3', 'product-3.PNG', '1'),
(13, 9, 'White Bridal 4', 'product-4.PNG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmincontact`
--

CREATE TABLE `tbladmincontact` (
  `contactId` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  `message` text NOT NULL,
  `attachFile` varchar(255) NOT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblbrand`
--

CREATE TABLE `tblbrand` (
  `brandId` int(11) NOT NULL,
  `brandName` varchar(255) NOT NULL,
  `image` varchar(200) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbrand`
--

INSERT INTO `tblbrand` (`brandId`, `brandName`, `image`, `status`, `createDate`) VALUES
(4, 'test', 'image7.jpg', '1', '2015-12-14 08:05:33'),
(5, 'brand', 'image9.jpg', '1', '2015-12-14 08:19:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbltest`
--

CREATE TABLE `tbltest` (
  `id` int(11) NOT NULL,
  `mobile` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `userId` int(11) UNSIGNED NOT NULL,
  `username` varchar(200) NOT NULL,
  `userEmailId` varchar(100) NOT NULL,
  `userPassword` varchar(100) NOT NULL,
  `companyname` varchar(100) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `contactperson` varchar(150) NOT NULL,
  `address` varchar(200) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `sendmessage` text NOT NULL,
  `emailId` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`userId`, `username`, `userEmailId`, `userPassword`, `companyname`, `mobile`, `contactperson`, `address`, `state`, `city`, `sendmessage`, `emailId`) VALUES
(1, 'Harsh Raj', 'php.yogendra@gmail.com', 'e6e061838856bf47e1de730719fb2609', 'E P L', '9015992826', '', 'Delhi', 'delhi', 'New Delhi', 'test message', 'php.yogendra@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent` (`parentId`),
  ADD KEY `status` (`status`),
  ADD KEY `sort` (`sort`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customerId`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`memid`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`ordetailId`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `productimage`
--
ALTER TABLE `productimage`
  ADD PRIMARY KEY (`pimageId`);

--
-- Indexes for table `tbladmincontact`
--
ALTER TABLE `tbladmincontact`
  ADD PRIMARY KEY (`contactId`);

--
-- Indexes for table `tblbrand`
--
ALTER TABLE `tblbrand`
  ADD PRIMARY KEY (`brandId`);

--
-- Indexes for table `tbltest`
--
ALTER TABLE `tbltest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customerId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `memid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `ordetailId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `productimage`
--
ALTER TABLE `productimage`
  MODIFY `pimageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbladmincontact`
--
ALTER TABLE `tbladmincontact`
  MODIFY `contactId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblbrand`
--
ALTER TABLE `tblbrand`
  MODIFY `brandId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbltest`
--
ALTER TABLE `tbltest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `userId` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
