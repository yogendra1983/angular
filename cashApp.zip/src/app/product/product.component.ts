import { Component } from '@angular/core';
import { UserinfoService } from '../userinfo.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {

  // result:any;
  // constructor( private _userinfo: UserinfoService ) {
  //   this._userinfo.getData().subscribe((result) => {console.log(result.data); 
    
  // });

  //  }



}
