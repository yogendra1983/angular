import { Injectable } from '@angular/core';
import {Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
@Injectable()
export class UserService {

  private isUserLoggedin;

  constructor( private _http: Http) {
    this.isUserLoggedin= false;
   }

   setUserLoggedIn(){
     this.isUserLoggedin = true;
   }

   getUserLoggedIn(){
     return this.isUserLoggedin;
   }

   saveProfile(jsonData){

   // console.log(jsonData);

     let _url: string ='http://localhost/cashApp/service/api/signup';
   //let datas = {"username":"yogendra@gmail.com", "password":123456 ,"address":"New ashok Nager", "state":"Bihar", "city":"Patna", "zip":110096 , "checkmeout":true};
     return this._http.post(_url,JSON.stringify(jsonData))
     .map(res => res.json());
   }


   loginUser(jsonData){

    //console.log(jsonData);
    let _url: string ='http://localhost/cashApp/service/api/login';
  //let datas = {"username":"yogendra@gmail.com", "password":123456 ,"address":"New ashok Nager", "state":"Bihar", "city":"Patna", "zip":110096 , "checkmeout":true};
    return this._http.post(_url,JSON.stringify(jsonData))
    .map(res => res.json());
  }

 






}
