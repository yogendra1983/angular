<?php
session_start();

echo "hi yogendra":



?>   